import { Switch, Route, Router as WouterRouter, useLocation } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { AuthProvider, useAuth } from "@/contexts/AuthContext";
import { isApproved, isHicomPlus } from "@/lib/utils";
import LoginPage from "@/pages/LoginPage";
import ApplyPage from "@/pages/ApplyPage";
import DashboardPage from "@/pages/DashboardPage";
import ApplicationsPage from "@/pages/ApplicationsPage";
import StaffPage from "@/pages/StaffPage";
import StaffProfilePage from "@/pages/StaffProfilePage";
import FilesPage from "@/pages/FilesPage";
import ChatPage from "@/pages/ChatPage";
import AdminPage from "@/pages/AdminPage";
import BotContextPage from "@/pages/BotContextPage";
import NotFound from "@/pages/not-found";

const queryClient = new QueryClient({
  defaultOptions: {
    queries: { retry: 1, staleTime: 10_000 },
  },
});

function AppRoutes() {
  const { user, isLoading } = useAuth();
  const [, setLocation] = useLocation();

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="h-8 w-8 border-2 border-primary border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  const approved = user && isApproved(user.status, user.role);

  return (
    <Switch>
      <Route path="/">
        {!user ? (
          <LoginPage />
        ) : approved ? (
          (() => { setLocation("/dashboard"); return null; })()
        ) : (
          <ApplyPage />
        )}
      </Route>

      <Route path="/apply">
        {!user ? <LoginPage /> : approved ? (() => { setLocation("/dashboard"); return null; })() : <ApplyPage />}
      </Route>

      <Route path="/dashboard">
        {!user ? <LoginPage /> : !approved ? <ApplyPage /> : <DashboardPage />}
      </Route>

      <Route path="/applications">
        {!user ? <LoginPage /> : !approved ? <ApplyPage /> : !isHicomPlus(user.role) ? <DashboardPage /> : <ApplicationsPage />}
      </Route>

      <Route path="/staff">
        {!user ? <LoginPage /> : !approved ? <ApplyPage /> : <StaffPage />}
      </Route>

      <Route path="/staff/:id">
        {!user ? <LoginPage /> : !approved ? <ApplyPage /> : <StaffProfilePage />}
      </Route>

      <Route path="/files">
        {!user ? <LoginPage /> : !approved ? <ApplyPage /> : <FilesPage />}
      </Route>

      <Route path="/chat">
        {!user ? <LoginPage /> : !approved ? <ApplyPage /> : <ChatPage />}
      </Route>

      <Route path="/admin">
        {!user ? <LoginPage /> : !approved ? <ApplyPage /> : user.role !== "owner" ? <DashboardPage /> : <AdminPage />}
      </Route>

      <Route path="/bot-context">
        {!user ? <LoginPage /> : !approved ? <ApplyPage /> : user.role !== "owner" ? <DashboardPage /> : <BotContextPage />}
      </Route>

      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")}>
          <AuthProvider>
            <AppRoutes />
          </AuthProvider>
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
