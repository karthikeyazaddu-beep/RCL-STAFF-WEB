import { getRoleLabel } from "@/lib/utils";

const roleClasses: Record<string, string> = {
  owner: "bg-yellow-500/20 text-yellow-400 border border-yellow-500/30",
  hicom: "bg-purple-500/20 text-purple-400 border border-purple-500/30",
  head_mod: "bg-red-500/20 text-red-400 border border-red-500/30",
  senior_mod: "bg-orange-500/20 text-orange-400 border border-orange-500/30",
  moderator: "bg-blue-500/20 text-blue-400 border border-blue-500/30",
  trial_mod: "bg-green-500/20 text-green-400 border border-green-500/30",
  pending: "bg-gray-500/20 text-gray-400 border border-gray-500/30",
  none: "bg-gray-500/20 text-gray-400 border border-gray-500/30",
};

export function RoleBadge({ role, size = "sm" }: { role: string; size?: "xs" | "sm" | "md" }) {
  const classes = roleClasses[role] ?? roleClasses.none;
  const sizeClasses = {
    xs: "text-xs px-1.5 py-0.5",
    sm: "text-xs px-2 py-1",
    md: "text-sm px-3 py-1",
  }[size];

  return (
    <span className={`inline-flex items-center rounded font-semibold uppercase tracking-wider ${classes} ${sizeClasses}`}>
      {getRoleLabel(role)}
    </span>
  );
}
