import { ReactNode } from "react";
import { Link, useLocation } from "wouter";
import { useAuth } from "@/contexts/AuthContext";
import { useLogout, getGetMeQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { getAvatarUrl, isHicomPlus, isApproved } from "@/lib/utils";
import { RoleBadge } from "./RoleBadge";
import {
  LayoutDashboard, Users, FileText, MessageSquare, ClipboardList, ShieldCheck, LogOut, Menu, Bot
} from "lucide-react";
import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";

const navItems = [
  { path: "/dashboard", label: "Dashboard", icon: LayoutDashboard },
  { path: "/applications", label: "Applications", icon: ClipboardList, hicomOnly: true },
  { path: "/staff", label: "Staff Directory", icon: Users },
  { path: "/files", label: "Files", icon: FileText },
  { path: "/chat", label: "AI Assistant", icon: MessageSquare },
  { path: "/bot-context", label: "Bot Context", icon: Bot, ownerOnly: true },
  { path: "/admin", label: "Admin", icon: ShieldCheck, ownerOnly: true },
];

export function Layout({ children }: { children: ReactNode }) {
  const { user } = useAuth();
  const [location] = useLocation();
  const [mobileOpen, setMobileOpen] = useState(false);
  const queryClient = useQueryClient();
  const logout = useLogout({
    mutation: {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getGetMeQueryKey() });
        window.location.href = "/";
      }
    }
  } as any);

  const visibleNav = navItems.filter(item => {
    if (item.ownerOnly && user?.role !== "owner") return false;
    if (item.hicomOnly && !isHicomPlus(user?.role ?? "none")) return false;
    return true;
  });

  const SidebarContent = () => (
    <div className="flex flex-col h-full">
      <div className="px-6 py-5 border-b border-border">
        <div className="flex items-center gap-2">
          <ShieldCheck className="h-6 w-6 text-primary" />
          <span className="font-bold text-lg tracking-tight">RCL Portal</span>
        </div>
        <p className="text-xs text-muted-foreground mt-0.5">Staff Management</p>
      </div>

      <nav className="flex-1 px-3 py-4 space-y-0.5">
        {visibleNav.map(item => {
          const Icon = item.icon;
          const active = location === item.path || location.startsWith(item.path + "/");
          return (
            <Link key={item.path} href={item.path} onClick={() => setMobileOpen(false)}>
              <div
                data-testid={`nav-${item.label.toLowerCase().replace(/\s+/g, "-")}`}
                className={`flex items-center gap-3 px-3 py-2 rounded-md text-sm font-medium transition-colors cursor-pointer ${
                  active
                    ? "bg-primary/15 text-primary"
                    : "text-muted-foreground hover:bg-accent hover:text-foreground"
                }`}
              >
                <Icon className="h-4 w-4 flex-shrink-0" />
                {item.label}
              </div>
            </Link>
          );
        })}
      </nav>

      {user && (
        <div className="px-3 py-4 border-t border-border">
          <div className="flex items-center gap-3 px-3 py-2 mb-1">
            <img
              src={getAvatarUrl(user.discordId, user.avatar)}
              alt={user.username}
              className="h-8 w-8 rounded-full border border-border"
            />
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium truncate">{user.username}</p>
              <RoleBadge role={user.role} size="xs" />
            </div>
          </div>
          <button
            data-testid="button-logout"
            onClick={() => logout.mutate(undefined as any)}
            className="flex items-center gap-2 w-full px-3 py-2 text-sm text-muted-foreground hover:text-destructive hover:bg-destructive/10 rounded-md transition-colors"
          >
            <LogOut className="h-4 w-4" />
            Sign Out
          </button>
        </div>
      )}
    </div>
  );

  return (
    <div className="flex h-screen bg-background overflow-hidden">
      {/* Desktop sidebar */}
      <aside className="hidden md:flex flex-col w-56 bg-sidebar border-r border-sidebar-border flex-shrink-0">
        <SidebarContent />
      </aside>

      {/* Mobile sidebar */}
      <AnimatePresence>
        {mobileOpen && (
          <>
            <motion.div
              initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
              className="fixed inset-0 bg-black/60 z-40 md:hidden"
              onClick={() => setMobileOpen(false)}
            />
            <motion.aside
              initial={{ x: -224 }} animate={{ x: 0 }} exit={{ x: -224 }}
              transition={{ type: "spring", damping: 25, stiffness: 300 }}
              className="fixed left-0 top-0 bottom-0 w-56 bg-sidebar border-r border-sidebar-border z-50 md:hidden"
            >
              <SidebarContent />
            </motion.aside>
          </>
        )}
      </AnimatePresence>

      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Mobile header */}
        <header className="md:hidden flex items-center gap-3 px-4 py-3 border-b border-border bg-sidebar">
          <button
            data-testid="button-mobile-menu"
            onClick={() => setMobileOpen(true)}
            className="text-muted-foreground hover:text-foreground"
          >
            <Menu className="h-5 w-5" />
          </button>
          <div className="flex items-center gap-2">
            <ShieldCheck className="h-5 w-5 text-primary" />
            <span className="font-bold tracking-tight">RCL Portal</span>
          </div>
        </header>

        <main className="flex-1 overflow-y-auto">
          {children}
        </main>
      </div>
    </div>
  );
}
