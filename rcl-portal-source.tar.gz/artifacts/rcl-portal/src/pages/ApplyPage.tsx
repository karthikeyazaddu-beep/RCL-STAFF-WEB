import { useAuth } from "@/contexts/AuthContext";
import { useSubmitApplication, useGetMyApplication, getGetMyApplicationQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { getAvatarUrl, formatDate } from "@/lib/utils";
import { Clock, CheckCircle, XCircle, AlertTriangle } from "lucide-react";
import { motion } from "framer-motion";

export default function ApplyPage() {
  const { user } = useAuth();
  const queryClient = useQueryClient();

  const { data: application, isLoading: appLoading } = useGetMyApplication({
    query: { retry: false, queryKey: ["/api/applications/my"] } as any
  });

  const submit = useSubmitApplication({
    mutation: {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getGetMyApplicationQueryKey() });
      }
    }
  });

  if (!user) return null;

  const isPending = application?.status === "pending";
  const isApprovedApp = application?.status === "approved";
  const isDeclined = application?.status === "declined";
  const isBlacklisted = application?.status === "blacklisted";

  return (
    <div className="min-h-screen bg-background flex items-center justify-center px-4">
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute -top-40 -right-40 w-96 h-96 bg-primary/5 rounded-full blur-3xl" />
      </div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="relative w-full max-w-md"
      >
        <div className="bg-card border border-card-border rounded-xl shadow-2xl overflow-hidden">
          <div className="px-8 py-8">
            <div className="flex flex-col items-center mb-8">
              <img
                src={getAvatarUrl(user.discordId, user.avatar)}
                alt={user.username}
                className="h-20 w-20 rounded-full border-2 border-primary/30 mb-4"
              />
              <h2 className="text-xl font-bold">{user.username}</h2>
              <p className="text-xs text-muted-foreground font-mono mt-1">{user.discordId}</p>
            </div>

            {appLoading ? (
              <div className="flex justify-center py-4">
                <div className="h-6 w-6 border-2 border-primary border-t-transparent rounded-full animate-spin" />
              </div>
            ) : isPending ? (
              <div className="bg-yellow-500/10 border border-yellow-500/30 rounded-lg p-4 text-center">
                <Clock className="h-6 w-6 text-yellow-400 mx-auto mb-2" />
                <p className="font-semibold text-yellow-400">Application Pending</p>
                <p className="text-sm text-muted-foreground mt-1">
                  Your application is under review. You will be notified once a decision is made.
                </p>
                {application?.createdAt && (
                  <p className="text-xs text-muted-foreground mt-2">Submitted {formatDate(application.createdAt)}</p>
                )}
              </div>
            ) : isApprovedApp ? (
              <div className="bg-green-500/10 border border-green-500/30 rounded-lg p-4 text-center">
                <CheckCircle className="h-6 w-6 text-green-400 mx-auto mb-2" />
                <p className="font-semibold text-green-400">Application Approved</p>
                <p className="text-sm text-muted-foreground mt-1">Redirecting to dashboard...</p>
              </div>
            ) : isBlacklisted ? (
              <div className="bg-destructive/10 border border-destructive/30 rounded-lg p-4 text-center">
                <AlertTriangle className="h-6 w-6 text-destructive mx-auto mb-2" />
                <p className="font-semibold text-destructive">Blacklisted</p>
                <p className="text-sm text-muted-foreground mt-1">
                  You cannot apply at this time.
                  {application?.blacklistedUntil && ` Expires: ${formatDate(application.blacklistedUntil)}`}
                </p>
              </div>
            ) : isDeclined ? (
              <div className="space-y-4">
                <div className="bg-orange-500/10 border border-orange-500/30 rounded-lg p-4 text-center">
                  <XCircle className="h-6 w-6 text-orange-400 mx-auto mb-2" />
                  <p className="font-semibold text-orange-400">Previous Application Declined</p>
                  <p className="text-sm text-muted-foreground mt-1">You may submit a new application.</p>
                </div>
                <button
                  data-testid="button-submit-application"
                  onClick={() => submit.mutate(undefined as any)}
                  disabled={submit.isPending}
                  className="w-full py-3 bg-primary hover:bg-primary/90 text-primary-foreground font-semibold rounded-lg transition-all active:scale-[0.98] disabled:opacity-60"
                >
                  {submit.isPending ? "Submitting..." : "Request Access"}
                </button>
              </div>
            ) : (
              <div className="space-y-4">
                <p className="text-sm text-muted-foreground text-center">
                  Submit a request to join the RCL staff team. Your application will be reviewed by HICOM.
                </p>
                <button
                  data-testid="button-submit-application"
                  onClick={() => submit.mutate(undefined as any)}
                  disabled={submit.isPending}
                  className="w-full py-3 bg-primary hover:bg-primary/90 text-primary-foreground font-semibold rounded-lg transition-all active:scale-[0.98] disabled:opacity-60"
                >
                  {submit.isPending ? "Submitting..." : "Request Access"}
                </button>
              </div>
            )}

            {submit.isError && (
              <p className="text-sm text-destructive mt-3 text-center">
                Failed to submit. Please try again.
              </p>
            )}
          </div>
        </div>
      </motion.div>
    </div>
  );
}
