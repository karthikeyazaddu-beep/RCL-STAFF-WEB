import { useGetStaffProfile, useUpdateStaffProfile, getGetStaffProfileQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Layout } from "@/components/Layout";
import { RoleBadge } from "@/components/RoleBadge";
import { useAuth } from "@/contexts/AuthContext";
import { getAvatarUrl, isHicomPlus, formatDate } from "@/lib/utils";
import { ArrowLeft, Edit2, Save, X, Clock, Info } from "lucide-react";
import { Link, useParams } from "wouter";
import { useState } from "react";
import { motion } from "framer-motion";

const ROLES = [
  { value: "trial_mod", label: "Trial Mod" },
  { value: "moderator", label: "Moderator" },
  { value: "senior_mod", label: "Senior Mod" },
  { value: "head_mod", label: "Head Mod" },
  { value: "hicom", label: "HICOM" },
];

export default function StaffProfilePage() {
  const params = useParams<{ id: string }>();
  const id = parseInt(params.id ?? "0", 10);
  const { user } = useAuth();
  const queryClient = useQueryClient();

  const { data: profile, isLoading } = useGetStaffProfile(id, {
    query: { queryKey: getGetStaffProfileQueryKey(id) }
  });

  const [editing, setEditing] = useState(false);
  const [form, setForm] = useState({ username: "", avatar: "", timezone: "", about: "", role: "" });

  const update = useUpdateStaffProfile({
    mutation: {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getGetStaffProfileQueryKey(id) });
        setEditing(false);
      }
    }
  });

  const canManage = isHicomPlus(user?.role ?? "none");

  const startEdit = () => {
    if (!profile) return;
    setForm({ username: profile.username, avatar: profile.avatar ?? "", timezone: profile.timezone ?? "", about: profile.about ?? "", role: profile.role });
    setEditing(true);
  };

  if (isLoading) {
    return <Layout><div className="flex justify-center py-16"><div className="h-8 w-8 border-2 border-primary border-t-transparent rounded-full animate-spin" /></div></Layout>;
  }

  if (!profile) {
    return <Layout><div className="p-6 text-center text-muted-foreground">Profile not found.</div></Layout>;
  }

  return (
    <Layout>
      <div className="p-6 max-w-2xl mx-auto">
        <Link href="/staff">
          <div className="flex items-center gap-2 text-muted-foreground hover:text-foreground transition-colors cursor-pointer mb-6 w-fit">
            <ArrowLeft className="h-4 w-4" />
            <span className="text-sm">Back to Staff Directory</span>
          </div>
        </Link>

        <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} className="bg-card border border-card-border rounded-xl overflow-hidden">
          <div className="bg-gradient-to-r from-primary/10 to-purple-500/5 px-6 pt-8 pb-6">
            <div className="flex items-start justify-between">
              <div className="flex items-center gap-4">
                <img
                  src={getAvatarUrl(profile.discordId, profile.avatar)}
                  alt={profile.username}
                  className="h-20 w-20 rounded-full border-2 border-primary/30 shadow-lg"
                />
                <div>
                  <h1 data-testid="text-profile-username" className="text-2xl font-bold">{profile.username}</h1>
                  <p className="text-xs text-muted-foreground font-mono mt-0.5 mb-2">{profile.discordId}</p>
                  <RoleBadge role={profile.role} size="md" />
                </div>
              </div>
              {canManage && !editing && (
                <button
                  data-testid="button-edit-profile"
                  onClick={startEdit}
                  className="flex items-center gap-2 px-3 py-1.5 border border-border rounded-lg text-sm hover:bg-accent transition-colors"
                >
                  <Edit2 className="h-3.5 w-3.5" />
                  Edit
                </button>
              )}
            </div>
          </div>

          <div className="px-6 py-6 space-y-4">
            {editing ? (
              <div className="space-y-4">
                {[
                  { key: "username", label: "Username" },
                  { key: "avatar", label: "Avatar Hash" },
                  { key: "timezone", label: "Timezone" },
                ].map(f => (
                  <div key={f.key}>
                    <label className="text-xs font-medium text-muted-foreground uppercase tracking-wider">{f.label}</label>
                    <input
                      data-testid={`input-edit-${f.key}`}
                      value={form[f.key as keyof typeof form]}
                      onChange={e => setForm(p => ({ ...p, [f.key]: e.target.value }))}
                      className="mt-1 w-full px-3 py-2 bg-muted/50 border border-input rounded-lg text-sm focus:outline-none focus:ring-1 focus:ring-ring"
                    />
                  </div>
                ))}
                <div>
                  <label className="text-xs font-medium text-muted-foreground uppercase tracking-wider">About</label>
                  <textarea
                    data-testid="input-edit-about"
                    value={form.about}
                    onChange={e => setForm(p => ({ ...p, about: e.target.value }))}
                    rows={3}
                    className="mt-1 w-full px-3 py-2 bg-muted/50 border border-input rounded-lg text-sm focus:outline-none focus:ring-1 focus:ring-ring resize-none"
                  />
                </div>
                <div>
                  <label className="text-xs font-medium text-muted-foreground uppercase tracking-wider">Role</label>
                  <select
                    data-testid="select-edit-role"
                    value={form.role}
                    onChange={e => setForm(p => ({ ...p, role: e.target.value }))}
                    className="mt-1 w-full px-3 py-2 bg-muted/50 border border-input rounded-lg text-sm focus:outline-none focus:ring-1 focus:ring-ring"
                  >
                    {ROLES.map(r => <option key={r.value} value={r.value}>{r.label}</option>)}
                  </select>
                </div>
                <div className="flex gap-3 pt-2">
                  <button onClick={() => setEditing(false)} className="flex items-center gap-2 flex-1 justify-center py-2 border border-border rounded-lg text-sm hover:bg-accent transition-colors">
                    <X className="h-4 w-4" /> Cancel
                  </button>
                  <button
                    data-testid="button-save-profile"
                    onClick={() => update.mutate({ id, data: { username: form.username, avatar: form.avatar || null, timezone: form.timezone || null, about: form.about || null, role: form.role as any } })}
                    disabled={update.isPending}
                    className="flex items-center gap-2 flex-1 justify-center py-2 bg-primary text-primary-foreground rounded-lg text-sm font-semibold disabled:opacity-60 transition-colors"
                  >
                    <Save className="h-4 w-4" />
                    {update.isPending ? "Saving..." : "Save Changes"}
                  </button>
                </div>
              </div>
            ) : (
              <>
                {profile.timezone && (
                  <div className="flex items-center gap-3 text-sm">
                    <Clock className="h-4 w-4 text-muted-foreground" />
                    <span data-testid="text-timezone">{profile.timezone}</span>
                  </div>
                )}
                {profile.about && (
                  <div className="flex items-start gap-3 text-sm">
                    <Info className="h-4 w-4 text-muted-foreground mt-0.5" />
                    <p data-testid="text-about" className="text-muted-foreground leading-relaxed">{profile.about}</p>
                  </div>
                )}
                <div className="pt-2 border-t border-border">
                  <p className="text-xs text-muted-foreground">Member since {formatDate(profile.createdAt)}</p>
                </div>
              </>
            )}
          </div>
        </motion.div>
      </div>
    </Layout>
  );
}
