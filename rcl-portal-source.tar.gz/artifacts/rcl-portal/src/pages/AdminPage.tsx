import { useState } from "react";
import { useListStaff, useUpdateStaffRole, getListStaffQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Layout } from "@/components/Layout";
import { RoleBadge } from "@/components/RoleBadge";
import { getAvatarUrl } from "@/lib/utils";
import { ShieldCheck } from "lucide-react";
import { motion } from "framer-motion";

const ROLES = [
  { value: "trial_mod", label: "Trial Mod" },
  { value: "moderator", label: "Moderator" },
  { value: "senior_mod", label: "Senior Mod" },
  { value: "head_mod", label: "Head Mod" },
  { value: "hicom", label: "HICOM" },
];

export default function AdminPage() {
  const queryClient = useQueryClient();
  const { data: staff, isLoading } = useListStaff();
  const [editingId, setEditingId] = useState<string | null>(null);
  const [newRole, setNewRole] = useState("");
  const [successId, setSuccessId] = useState<string | null>(null);

  const updateRole = useUpdateStaffRole({
    mutation: {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getListStaffQueryKey() });
        setSuccessId(editingId);
        setEditingId(null);
        setTimeout(() => setSuccessId(null), 2000);
      }
    }
  });

  return (
    <Layout>
      <div className="p-6 max-w-3xl mx-auto">
        <div className="mb-6">
          <div className="flex items-center gap-3 mb-1">
            <ShieldCheck className="h-6 w-6 text-yellow-400" />
            <h1 className="text-2xl font-bold">Admin Panel</h1>
          </div>
          <p className="text-muted-foreground text-sm">Owner-only controls. You can assign any role including HICOM.</p>
        </div>

        <div className="bg-yellow-500/10 border border-yellow-500/30 rounded-xl p-4 mb-6">
          <p className="text-sm text-yellow-400 font-medium">Owner Access Only</p>
          <p className="text-xs text-muted-foreground mt-1">Role changes made here take effect immediately and update the staff member's permissions across the portal.</p>
        </div>

        {isLoading ? (
          <div className="flex justify-center py-16">
            <div className="h-8 w-8 border-2 border-primary border-t-transparent rounded-full animate-spin" />
          </div>
        ) : (
          <motion.div className="space-y-2" initial="hidden" animate="show"
            variants={{ hidden: {}, show: { transition: { staggerChildren: 0.05 } } }}>
            {(staff ?? []).map(s => (
              <motion.div
                key={s.id}
                data-testid={`admin-staff-row-${s.id}`}
                variants={{ hidden: { opacity: 0, x: -8 }, show: { opacity: 1, x: 0 } }}
                className={`flex items-center gap-4 bg-card border rounded-xl px-5 py-4 transition-colors ${
                  successId === s.discordId ? "border-green-500/40 bg-green-500/5" : "border-card-border"
                }`}
              >
                <img
                  src={getAvatarUrl(s.discordId, s.avatar)}
                  alt={s.username}
                  className="h-10 w-10 rounded-full border border-border flex-shrink-0"
                />
                <div className="flex-1 min-w-0">
                  <p className="font-semibold text-sm">{s.username}</p>
                  <p className="text-xs text-muted-foreground font-mono">{s.discordId}</p>
                </div>
                <div className="flex items-center gap-3 flex-shrink-0">
                  {editingId === s.discordId ? (
                    <div className="flex items-center gap-2">
                      <select
                        data-testid={`select-role-${s.id}`}
                        value={newRole}
                        onChange={e => setNewRole(e.target.value)}
                        className="px-2 py-1.5 bg-muted/50 border border-input rounded-lg text-sm focus:outline-none focus:ring-1 focus:ring-ring"
                      >
                        {ROLES.map(r => <option key={r.value} value={r.value}>{r.label}</option>)}
                      </select>
                      <button
                        data-testid={`button-save-role-${s.id}`}
                        onClick={() => updateRole.mutate({ userId: s.discordId, data: { role: newRole as any } })}
                        disabled={updateRole.isPending}
                        className="px-3 py-1.5 bg-primary text-primary-foreground text-xs font-semibold rounded-lg disabled:opacity-60"
                      >
                        Save
                      </button>
                      <button onClick={() => setEditingId(null)} className="px-3 py-1.5 border border-border text-xs rounded-lg hover:bg-accent">
                        Cancel
                      </button>
                    </div>
                  ) : (
                    <>
                      <RoleBadge role={s.role} size="xs" />
                      <button
                        data-testid={`button-change-role-${s.id}`}
                        onClick={() => { setEditingId(s.discordId); setNewRole(s.role); }}
                        className="px-3 py-1.5 border border-border text-xs rounded-lg hover:bg-accent hover:border-primary/30 transition-colors"
                      >
                        Change Role
                      </button>
                    </>
                  )}
                </div>
              </motion.div>
            ))}
          </motion.div>
        )}
      </div>
    </Layout>
  );
}
