import { useAuth } from "@/contexts/AuthContext";
import { ShieldCheck, AlertTriangle, Clock } from "lucide-react";
import { SiDiscord } from "react-icons/si";
import { motion } from "framer-motion";
import { formatDate } from "@/lib/utils";

export default function LoginPage() {
  const { user, isLoading } = useAuth();

  const handleLogin = () => {
    window.location.href = "/api/auth/discord";
  };

  const isBlacklisted = user?.status === "blacklisted";
  const isDeclined = user?.status === "declined";

  return (
    <div className="min-h-screen bg-background flex items-center justify-center px-4">
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute -top-40 -right-40 w-96 h-96 bg-primary/5 rounded-full blur-3xl" />
        <div className="absolute -bottom-40 -left-40 w-96 h-96 bg-purple-500/5 rounded-full blur-3xl" />
      </div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4 }}
        className="relative w-full max-w-md"
      >
        <div className="bg-card border border-card-border rounded-xl shadow-2xl overflow-hidden">
          <div className="px-8 pt-10 pb-8">
            <div className="flex items-center justify-center mb-8">
              <div className="flex items-center gap-3">
                <div className="p-3 bg-primary/10 rounded-xl">
                  <ShieldCheck className="h-8 w-8 text-primary" />
                </div>
                <div>
                  <h1 className="text-2xl font-bold tracking-tight">RCL Portal</h1>
                  <p className="text-xs text-muted-foreground uppercase tracking-widest">Staff Management</p>
                </div>
              </div>
            </div>

            {isBlacklisted ? (
              <motion.div
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                className="bg-destructive/10 border border-destructive/30 rounded-lg p-5 mb-6"
              >
                <div className="flex items-start gap-3">
                  <AlertTriangle className="h-5 w-5 text-destructive mt-0.5 flex-shrink-0" />
                  <div>
                    <p className="font-semibold text-destructive">Access Blacklisted</p>
                    <p className="text-sm text-muted-foreground mt-1">
                      You have been blacklisted from applying.
                      {user?.blacklistedUntil && (
                        <> Your restriction expires on <strong>{formatDate(user.blacklistedUntil)}</strong>.</>
                      )}
                    </p>
                  </div>
                </div>
              </motion.div>
            ) : isDeclined ? (
              <motion.div
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                className="bg-orange-500/10 border border-orange-500/30 rounded-lg p-5 mb-6"
              >
                <div className="flex items-start gap-3">
                  <Clock className="h-5 w-5 text-orange-400 mt-0.5 flex-shrink-0" />
                  <div>
                    <p className="font-semibold text-orange-400">Application Declined</p>
                    <p className="text-sm text-muted-foreground mt-1">
                      Your previous application was declined. You may submit a new request.
                    </p>
                  </div>
                </div>
              </motion.div>
            ) : null}

            {!isLoading && (
              <div className="space-y-3">
                {!isBlacklisted && (
                  <button
                    data-testid="button-login-discord"
                    onClick={handleLogin}
                    className="w-full flex items-center justify-center gap-3 px-5 py-3 bg-[#5865F2] hover:bg-[#4752c4] text-white font-semibold rounded-lg transition-all duration-200 active:scale-[0.98]"
                  >
                    <SiDiscord className="h-5 w-5" />
                    Sign in with Discord
                  </button>
                )}
                <p className="text-xs text-center text-muted-foreground">
                  Only authorized RCL staff may access this portal
                </p>
              </div>
            )}
          </div>

          <div className="bg-muted/30 px-8 py-4 border-t border-border">
            <p className="text-xs text-muted-foreground text-center">
              RCL Staff Portal &middot; Restricted Access
            </p>
          </div>
        </div>
      </motion.div>
    </div>
  );
}
