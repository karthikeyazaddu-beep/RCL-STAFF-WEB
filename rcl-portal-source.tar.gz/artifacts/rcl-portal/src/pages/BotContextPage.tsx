import { useState } from "react";
import {
  useListBotContext,
  useCreateBotContext,
  useUpdateBotContext,
  useDeleteBotContext,
  getListBotContextQueryKey,
} from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Layout } from "@/components/Layout";
import { formatDate } from "@/lib/utils";
import { Bot, Plus, Edit2, Trash2, Save, X, Lightbulb } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

type Entry = { id: number; title: string; content: string; createdAt: string; updatedAt?: string | null };

export default function BotContextPage() {
  const queryClient = useQueryClient();
  const { data: entries, isLoading } = useListBotContext();

  const [showAdd, setShowAdd] = useState(false);
  const [newTitle, setNewTitle] = useState("");
  const [newContent, setNewContent] = useState("");
  const [editingId, setEditingId] = useState<number | null>(null);
  const [editTitle, setEditTitle] = useState("");
  const [editContent, setEditContent] = useState("");

  const invalidate = () => queryClient.invalidateQueries({ queryKey: getListBotContextQueryKey() });

  const create = useCreateBotContext({
    mutation: {
      onSuccess: () => {
        invalidate();
        setShowAdd(false);
        setNewTitle("");
        setNewContent("");
      },
    },
  });

  const update = useUpdateBotContext({
    mutation: {
      onSuccess: () => {
        invalidate();
        setEditingId(null);
      },
    },
  });

  const remove = useDeleteBotContext({ mutation: { onSuccess: invalidate } });

  const startEdit = (entry: Entry) => {
    setEditingId(entry.id);
    setEditTitle(entry.title);
    setEditContent(entry.content);
  };

  return (
    <Layout>
      <div className="p-6 max-w-3xl mx-auto">
        <div className="flex items-start justify-between mb-6">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <Bot className="h-6 w-6 text-primary" />
              <h1 className="text-2xl font-bold">AI Chatbot Context</h1>
            </div>
            <p className="text-muted-foreground text-sm">
              Add custom instructions, rules, and information that the AI chatbot will always follow and reference.
            </p>
          </div>
          <button
            data-testid="button-add-context"
            onClick={() => setShowAdd(true)}
            className="flex items-center gap-2 px-4 py-2 bg-primary text-primary-foreground rounded-lg text-sm font-semibold hover:bg-primary/90 transition-colors flex-shrink-0"
          >
            <Plus className="h-4 w-4" />
            Add Entry
          </button>
        </div>

        {/* Info banner */}
        <div className="flex items-start gap-3 bg-primary/10 border border-primary/20 rounded-xl px-4 py-3 mb-6">
          <Lightbulb className="h-4 w-4 text-primary mt-0.5 flex-shrink-0" />
          <p className="text-sm text-muted-foreground">
            Everything you write here is injected into the AI's memory as <strong className="text-foreground">custom instructions</strong>. 
            Use it to define server rules, punishment guidelines, bot prefixes, channel IDs, escalation procedures, or anything else the AI should know.
          </p>
        </div>

        {isLoading ? (
          <div className="flex justify-center py-16">
            <div className="h-8 w-8 border-2 border-primary border-t-transparent rounded-full animate-spin" />
          </div>
        ) : entries && entries.length > 0 ? (
          <motion.div
            className="space-y-3"
            initial="hidden"
            animate="show"
            variants={{ hidden: {}, show: { transition: { staggerChildren: 0.06 } } }}
          >
            <AnimatePresence>
              {entries.map((entry) => (
                <motion.div
                  key={entry.id}
                  data-testid={`context-entry-${entry.id}`}
                  variants={{ hidden: { opacity: 0, y: 8 }, show: { opacity: 1, y: 0 } }}
                  exit={{ opacity: 0, x: -20 }}
                  className="bg-card border border-card-border rounded-xl overflow-hidden"
                >
                  {editingId === entry.id ? (
                    <div className="p-5 space-y-3">
                      <input
                        data-testid="input-edit-title"
                        value={editTitle}
                        onChange={(e) => setEditTitle(e.target.value)}
                        placeholder="Entry title..."
                        className="w-full px-3 py-2 bg-muted/50 border border-input rounded-lg text-sm font-semibold focus:outline-none focus:ring-1 focus:ring-ring"
                      />
                      <textarea
                        data-testid="input-edit-content"
                        value={editContent}
                        onChange={(e) => setEditContent(e.target.value)}
                        placeholder="Enter context, rules, or instructions..."
                        rows={6}
                        className="w-full px-3 py-2 bg-muted/50 border border-input rounded-lg text-sm focus:outline-none focus:ring-1 focus:ring-ring resize-y"
                      />
                      <div className="flex gap-2 justify-end">
                        <button
                          onClick={() => setEditingId(null)}
                          className="flex items-center gap-1.5 px-3 py-1.5 border border-border rounded-lg text-sm hover:bg-accent transition-colors"
                        >
                          <X className="h-3.5 w-3.5" />
                          Cancel
                        </button>
                        <button
                          data-testid="button-save-edit"
                          onClick={() =>
                            update.mutate({ id: entry.id, data: { title: editTitle, content: editContent } })
                          }
                          disabled={update.isPending || !editTitle.trim() || !editContent.trim()}
                          className="flex items-center gap-1.5 px-3 py-1.5 bg-primary text-primary-foreground rounded-lg text-sm font-semibold hover:bg-primary/90 disabled:opacity-60 transition-colors"
                        >
                          <Save className="h-3.5 w-3.5" />
                          {update.isPending ? "Saving..." : "Save"}
                        </button>
                      </div>
                    </div>
                  ) : (
                    <div className="p-5">
                      <div className="flex items-start justify-between gap-3 mb-3">
                        <div>
                          <h3
                            data-testid={`text-entry-title-${entry.id}`}
                            className="font-semibold text-sm"
                          >
                            {entry.title}
                          </h3>
                          <p className="text-xs text-muted-foreground mt-0.5">
                            Added {formatDate(entry.createdAt)}
                            {entry.updatedAt && entry.updatedAt !== entry.createdAt && (
                              <> &middot; Edited {formatDate(entry.updatedAt)}</>
                            )}
                          </p>
                        </div>
                        <div className="flex items-center gap-1 flex-shrink-0">
                          <button
                            data-testid={`button-edit-${entry.id}`}
                            onClick={() => startEdit(entry)}
                            className="p-1.5 text-muted-foreground hover:text-foreground hover:bg-accent rounded transition-colors"
                          >
                            <Edit2 className="h-3.5 w-3.5" />
                          </button>
                          <button
                            data-testid={`button-delete-${entry.id}`}
                            onClick={() => remove.mutate({ id: entry.id })}
                            className="p-1.5 text-muted-foreground hover:text-destructive hover:bg-destructive/10 rounded transition-colors"
                          >
                            <Trash2 className="h-3.5 w-3.5" />
                          </button>
                        </div>
                      </div>
                      <p
                        data-testid={`text-entry-content-${entry.id}`}
                        className="text-sm text-muted-foreground whitespace-pre-wrap leading-relaxed bg-muted/30 rounded-lg px-3 py-2"
                      >
                        {entry.content}
                      </p>
                    </div>
                  )}
                </motion.div>
              ))}
            </AnimatePresence>
          </motion.div>
        ) : (
          <div className="text-center py-16 text-muted-foreground">
            <Bot className="h-10 w-10 mx-auto mb-3 opacity-30" />
            <p className="font-medium">No context entries yet</p>
            <p className="text-sm mt-1">Add instructions to teach the AI about your server's specific rules and procedures.</p>
          </div>
        )}

        {/* Add entry panel */}
        <AnimatePresence>
          {showAdd && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center px-4"
              onClick={(e) => e.target === e.currentTarget && setShowAdd(false)}
            >
              <motion.div
                initial={{ scale: 0.95, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                exit={{ scale: 0.95, opacity: 0 }}
                className="bg-card border border-card-border rounded-xl p-6 w-full max-w-lg shadow-2xl"
              >
                <h3 className="font-bold text-lg mb-1">Add Context Entry</h3>
                <p className="text-sm text-muted-foreground mb-4">
                  This will be injected into the AI's system prompt every time someone chats.
                </p>
                <div className="space-y-3">
                  <div>
                    <label className="text-xs font-medium text-muted-foreground uppercase tracking-wider">
                      Title
                    </label>
                    <input
                      data-testid="input-new-title"
                      value={newTitle}
                      onChange={(e) => setNewTitle(e.target.value)}
                      placeholder="e.g. Punishment Guidelines, Bot Commands, Channel IDs..."
                      className="mt-1 w-full px-3 py-2 bg-muted/50 border border-input rounded-lg text-sm focus:outline-none focus:ring-1 focus:ring-ring"
                    />
                  </div>
                  <div>
                    <label className="text-xs font-medium text-muted-foreground uppercase tracking-wider">
                      Content
                    </label>
                    <textarea
                      data-testid="input-new-content"
                      value={newContent}
                      onChange={(e) => setNewContent(e.target.value)}
                      placeholder="Write the rules, instructions, or information the AI should know..."
                      rows={8}
                      className="mt-1 w-full px-3 py-2 bg-muted/50 border border-input rounded-lg text-sm focus:outline-none focus:ring-1 focus:ring-ring resize-y"
                    />
                  </div>
                </div>
                <div className="flex gap-3 mt-5">
                  <button
                    onClick={() => { setShowAdd(false); setNewTitle(""); setNewContent(""); }}
                    className="flex-1 py-2 border border-border rounded-lg text-sm hover:bg-accent transition-colors"
                  >
                    Cancel
                  </button>
                  <button
                    data-testid="button-create-context"
                    onClick={() => create.mutate({ data: { title: newTitle, content: newContent } })}
                    disabled={create.isPending || !newTitle.trim() || !newContent.trim()}
                    className="flex-1 py-2 bg-primary text-primary-foreground rounded-lg text-sm font-semibold hover:bg-primary/90 disabled:opacity-60 transition-colors"
                  >
                    {create.isPending ? "Adding..." : "Add Entry"}
                  </button>
                </div>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </Layout>
  );
}
