import { useAuth } from "@/contexts/AuthContext";
import { useGetApplicationStats, useListStaff, useListFiles } from "@workspace/api-client-react";
import { Layout } from "@/components/Layout";
import { RoleBadge } from "@/components/RoleBadge";
import { getAvatarUrl, getRoleLabel, isHicomPlus } from "@/lib/utils";
import { ClipboardList, Users, FileText, MessageSquare, TrendingUp, Shield } from "lucide-react";
import { Link } from "wouter";
import { motion } from "framer-motion";

const container = {
  hidden: { opacity: 0 },
  show: { opacity: 1, transition: { staggerChildren: 0.07 } },
};
const item = { hidden: { opacity: 0, y: 12 }, show: { opacity: 1, y: 0 } };

export default function DashboardPage() {
  const { user } = useAuth();
  const { data: stats } = useGetApplicationStats();
  const { data: staff } = useListStaff();
  const { data: files } = useListFiles();

  if (!user) return null;

  const hicom = isHicomPlus(user.role);

  const quickStats = [
    ...(hicom ? [{ label: "Pending Applications", value: stats?.pending ?? 0, icon: ClipboardList, color: "text-yellow-400", bg: "bg-yellow-500/10", href: "/applications" }] : []),
    { label: "Staff Members", value: staff?.length ?? 0, icon: Users, color: "text-blue-400", bg: "bg-blue-500/10", href: "/staff" },
    { label: "Files Available", value: files?.length ?? 0, icon: FileText, color: "text-green-400", bg: "bg-green-500/10", href: "/files" },
    ...(hicom ? [{ label: "Total Applications", value: stats?.total ?? 0, icon: TrendingUp, color: "text-purple-400", bg: "bg-purple-500/10", href: "/applications" }] : []),
  ];

  return (
    <Layout>
      <div className="p-6 max-w-5xl mx-auto">
        <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }} className="mb-8">
          <div className="flex items-center gap-4">
            <img
              src={getAvatarUrl(user.discordId, user.avatar)}
              alt={user.username}
              className="h-14 w-14 rounded-full border-2 border-primary/30"
            />
            <div>
              <div className="flex items-center gap-2 mb-1">
                <h1 className="text-2xl font-bold">Welcome, {user.username}</h1>
                <RoleBadge role={user.role} size="sm" />
              </div>
              <p className="text-muted-foreground text-sm">
                {getRoleLabel(user.role)} &middot; RCL Staff Portal
              </p>
            </div>
          </div>
        </motion.div>

        <motion.div variants={container} initial="hidden" animate="show" className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          {quickStats.map((s) => {
            const Icon = s.icon;
            return (
              <motion.div key={s.label} variants={item}>
                <Link href={s.href}>
                  <div data-testid={`stat-card-${s.label.toLowerCase().replace(/\s+/g, "-")}`}
                    className="bg-card border border-card-border rounded-xl p-4 hover:border-primary/30 transition-colors cursor-pointer group"
                  >
                    <div className={`inline-flex p-2 rounded-lg ${s.bg} mb-3`}>
                      <Icon className={`h-5 w-5 ${s.color}`} />
                    </div>
                    <p className="text-2xl font-bold group-hover:text-primary transition-colors">{s.value}</p>
                    <p className="text-xs text-muted-foreground mt-1">{s.label}</p>
                  </div>
                </Link>
              </motion.div>
            );
          })}
        </motion.div>

        <div className="grid md:grid-cols-2 gap-6">
          <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }}>
            <div className="bg-card border border-card-border rounded-xl p-5">
              <h2 className="font-semibold mb-4 flex items-center gap-2">
                <Users className="h-4 w-4 text-primary" />
                Recent Staff
              </h2>
              {staff && staff.length > 0 ? (
                <div className="space-y-3">
                  {staff.slice(0, 5).map((s) => (
                    <Link key={s.id} href={`/staff/${s.id}`}>
                      <div data-testid={`staff-item-${s.id}`} className="flex items-center gap-3 hover:bg-accent rounded-lg p-2 -mx-2 transition-colors cursor-pointer">
                        <img
                          src={getAvatarUrl(s.discordId, s.avatar)}
                          alt={s.username}
                          className="h-8 w-8 rounded-full border border-border"
                        />
                        <div className="flex-1 min-w-0">
                          <p className="text-sm font-medium truncate">{s.username}</p>
                          <p className="text-xs text-muted-foreground">{s.timezone ?? "No timezone set"}</p>
                        </div>
                        <RoleBadge role={s.role} size="xs" />
                      </div>
                    </Link>
                  ))}
                </div>
              ) : (
                <p className="text-sm text-muted-foreground">No staff profiles yet.</p>
              )}
            </div>
          </motion.div>

          <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }}>
            <div className="bg-card border border-card-border rounded-xl p-5">
              <h2 className="font-semibold mb-4 flex items-center gap-2">
                <Shield className="h-4 w-4 text-primary" />
                Quick Navigation
              </h2>
              <div className="space-y-2">
                {[
                  { href: "/staff", label: "View Staff Directory", icon: Users },
                  { href: "/files", label: "Browse Files", icon: FileText },
                  { href: "/chat", label: "Ask AI Assistant", icon: MessageSquare },
                  ...(hicom ? [{ href: "/applications", label: "Review Applications", icon: ClipboardList }] : []),
                ].map((link) => {
                  const Icon = link.icon;
                  return (
                    <Link key={link.href} href={link.href}>
                      <div
                        data-testid={`quick-link-${link.label.toLowerCase().replace(/\s+/g, "-")}`}
                        className="flex items-center gap-3 px-3 py-2.5 rounded-lg hover:bg-accent transition-colors cursor-pointer group"
                      >
                        <Icon className="h-4 w-4 text-muted-foreground group-hover:text-primary transition-colors" />
                        <span className="text-sm font-medium">{link.label}</span>
                      </div>
                    </Link>
                  );
                })}
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </Layout>
  );
}
