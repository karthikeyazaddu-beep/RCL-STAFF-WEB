import { useState } from "react";
import { useListApplications, useApproveApplication, useDeclineApplication, useBlacklistApplicant, getListApplicationsQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Layout } from "@/components/Layout";
import { getAvatarUrl, formatDate } from "@/lib/utils";
import { CheckCircle, XCircle, AlertTriangle, Clock, Filter } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

const ROLES = [
  { value: "trial_mod", label: "Trial Mod" },
  { value: "moderator", label: "Moderator" },
  { value: "senior_mod", label: "Senior Mod" },
  { value: "head_mod", label: "Head Mod" },
];

const statusColors: Record<string, string> = {
  pending: "bg-yellow-500/10 text-yellow-400 border-yellow-500/30",
  approved: "bg-green-500/10 text-green-400 border-green-500/30",
  declined: "bg-gray-500/10 text-gray-400 border-gray-500/30",
  blacklisted: "bg-destructive/10 text-destructive border-destructive/30",
};

export default function ApplicationsPage() {
  const queryClient = useQueryClient();
  const { data: applications, isLoading } = useListApplications();
  const [filter, setFilter] = useState<"all" | "pending" | "approved" | "declined" | "blacklisted">("pending");
  const [blacklistConfirm, setBlacklistConfirm] = useState<number | null>(null);
  const [approveModal, setApproveModal] = useState<{ id: number; username: string } | null>(null);
  const [selectedRole, setSelectedRole] = useState("trial_mod");

  const invalidate = () => queryClient.invalidateQueries({ queryKey: getListApplicationsQueryKey() });

  const approve = useApproveApplication({ mutation: { onSuccess: () => { invalidate(); setApproveModal(null); } } });
  const decline = useDeclineApplication({ mutation: { onSuccess: invalidate } });
  const blacklist = useBlacklistApplicant({ mutation: { onSuccess: () => { invalidate(); setBlacklistConfirm(null); } } });

  const filtered = (applications ?? []).filter(a => filter === "all" || a.status === filter);

  return (
    <Layout>
      <div className="p-6 max-w-4xl mx-auto">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="text-2xl font-bold">Applications</h1>
            <p className="text-muted-foreground text-sm mt-1">Review and manage staff access requests</p>
          </div>
          <div className="flex items-center gap-1 bg-muted/50 rounded-lg p-1">
            <Filter className="h-4 w-4 text-muted-foreground ml-2" />
            {(["pending", "approved", "declined", "blacklisted", "all"] as const).map(f => (
              <button
                key={f}
                data-testid={`filter-${f}`}
                onClick={() => setFilter(f)}
                className={`px-3 py-1.5 text-xs font-medium rounded-md capitalize transition-colors ${filter === f ? "bg-card text-foreground shadow-sm" : "text-muted-foreground hover:text-foreground"}`}
              >
                {f}
              </button>
            ))}
          </div>
        </div>

        {isLoading ? (
          <div className="flex justify-center py-16">
            <div className="h-8 w-8 border-2 border-primary border-t-transparent rounded-full animate-spin" />
          </div>
        ) : filtered.length === 0 ? (
          <div className="text-center py-16 text-muted-foreground">
            <Clock className="h-10 w-10 mx-auto mb-3 opacity-30" />
            <p>No {filter === "all" ? "" : filter} applications</p>
          </div>
        ) : (
          <motion.div className="space-y-3" initial="hidden" animate="show"
            variants={{ hidden: {}, show: { transition: { staggerChildren: 0.05 } } }}>
            <AnimatePresence>
              {filtered.map(app => (
                <motion.div
                  key={app.id}
                  data-testid={`application-card-${app.id}`}
                  variants={{ hidden: { opacity: 0, y: 8 }, show: { opacity: 1, y: 0 } }}
                  exit={{ opacity: 0, x: -20 }}
                  className="bg-card border border-card-border rounded-xl p-4"
                >
                  <div className="flex items-center gap-4">
                    <img
                      src={getAvatarUrl(app.discordId, app.avatar)}
                      alt={app.username}
                      className="h-12 w-12 rounded-full border border-border flex-shrink-0"
                    />
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span data-testid={`text-username-${app.id}`} className="font-semibold">{app.username}</span>
                        <span className={`text-xs px-2 py-0.5 rounded border capitalize ${statusColors[app.status]}`}>
                          {app.status}
                        </span>
                        {app.role && <span className="text-xs text-muted-foreground">→ {app.role.replace(/_/g, " ")}</span>}
                      </div>
                      <p className="text-xs text-muted-foreground font-mono mt-0.5">{app.discordId}</p>
                      <p className="text-xs text-muted-foreground mt-1">Applied {formatDate(app.createdAt)}</p>
                    </div>

                    {app.status === "pending" && (
                      <div className="flex items-center gap-2 flex-shrink-0">
                        <button
                          data-testid={`button-approve-${app.id}`}
                          onClick={() => { setApproveModal({ id: app.id, username: app.username }); setSelectedRole("trial_mod"); }}
                          className="flex items-center gap-1.5 px-3 py-1.5 bg-green-500/15 hover:bg-green-500/25 text-green-400 text-sm font-medium rounded-lg transition-colors"
                        >
                          <CheckCircle className="h-3.5 w-3.5" />
                          Approve
                        </button>
                        <button
                          data-testid={`button-decline-${app.id}`}
                          onClick={() => decline.mutate({ id: app.id })}
                          disabled={decline.isPending}
                          className="flex items-center gap-1.5 px-3 py-1.5 bg-gray-500/15 hover:bg-gray-500/25 text-gray-400 text-sm font-medium rounded-lg transition-colors disabled:opacity-50"
                        >
                          <XCircle className="h-3.5 w-3.5" />
                          Decline
                        </button>
                        <button
                          data-testid={`button-blacklist-${app.id}`}
                          onClick={() => setBlacklistConfirm(app.id)}
                          className="flex items-center gap-1.5 px-3 py-1.5 bg-destructive/15 hover:bg-destructive/25 text-destructive text-sm font-medium rounded-lg transition-colors"
                        >
                          <AlertTriangle className="h-3.5 w-3.5" />
                          Blacklist
                        </button>
                      </div>
                    )}
                  </div>
                </motion.div>
              ))}
            </AnimatePresence>
          </motion.div>
        )}
      </div>

      {/* Approve modal */}
      <AnimatePresence>
        {approveModal && (
          <motion.div
            initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center px-4"
            onClick={(e) => e.target === e.currentTarget && setApproveModal(null)}
          >
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} exit={{ scale: 0.95, opacity: 0 }}
              className="bg-card border border-card-border rounded-xl p-6 w-full max-w-sm shadow-2xl"
            >
              <h3 className="font-bold text-lg mb-1">Approve Application</h3>
              <p className="text-sm text-muted-foreground mb-4">Assign a role to <strong>{approveModal.username}</strong></p>
              <div className="space-y-2 mb-5">
                {ROLES.map(r => (
                  <label key={r.value} data-testid={`role-option-${r.value}`} className="flex items-center gap-3 p-3 rounded-lg border border-border hover:border-primary/30 cursor-pointer transition-colors">
                    <input
                      type="radio"
                      name="role"
                      value={r.value}
                      checked={selectedRole === r.value}
                      onChange={() => setSelectedRole(r.value)}
                      className="accent-primary"
                    />
                    <span className="text-sm font-medium">{r.label}</span>
                  </label>
                ))}
              </div>
              <div className="flex gap-3">
                <button onClick={() => setApproveModal(null)} className="flex-1 py-2 border border-border rounded-lg text-sm hover:bg-accent transition-colors">
                  Cancel
                </button>
                <button
                  data-testid="button-confirm-approve"
                  onClick={() => approve.mutate({ id: approveModal.id, data: { role: selectedRole as any } })}
                  disabled={approve.isPending}
                  className="flex-1 py-2 bg-primary text-primary-foreground rounded-lg text-sm font-semibold hover:bg-primary/90 transition-colors disabled:opacity-60"
                >
                  {approve.isPending ? "Approving..." : "Approve"}
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Blacklist confirm modal */}
      <AnimatePresence>
        {blacklistConfirm !== null && (
          <motion.div
            initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center px-4"
            onClick={(e) => e.target === e.currentTarget && setBlacklistConfirm(null)}
          >
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} exit={{ scale: 0.95, opacity: 0 }}
              className="bg-card border border-destructive/30 rounded-xl p-6 w-full max-w-sm shadow-2xl"
            >
              <AlertTriangle className="h-8 w-8 text-destructive mb-3" />
              <h3 className="font-bold text-lg mb-1">Confirm Blacklist</h3>
              <p className="text-sm text-muted-foreground mb-5">
                This will prevent the user from applying for <strong>10 days</strong>. This action cannot be undone.
              </p>
              <div className="flex gap-3">
                <button onClick={() => setBlacklistConfirm(null)} className="flex-1 py-2 border border-border rounded-lg text-sm hover:bg-accent transition-colors">
                  Cancel
                </button>
                <button
                  data-testid="button-confirm-blacklist"
                  onClick={() => blacklist.mutate({ id: blacklistConfirm })}
                  disabled={blacklist.isPending}
                  className="flex-1 py-2 bg-destructive text-destructive-foreground rounded-lg text-sm font-semibold hover:bg-destructive/90 transition-colors disabled:opacity-60"
                >
                  {blacklist.isPending ? "Blacklisting..." : "Blacklist"}
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </Layout>
  );
}
