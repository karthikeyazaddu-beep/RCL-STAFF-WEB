import { useState, useRef, useEffect } from "react";
import { useSendChatMessage, useGetChatHistory, getGetChatHistoryQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Layout } from "@/components/Layout";
import { useAuth } from "@/contexts/AuthContext";
import { getAvatarUrl } from "@/lib/utils";
import { Send, Bot, User as UserIcon } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

export default function ChatPage() {
  const { user } = useAuth();
  const queryClient = useQueryClient();
  const [input, setInput] = useState("");
  const [optimisticMessages, setOptimisticMessages] = useState<Array<{ id: number; role: string; content: string; createdAt: string }>>([]);
  const bottomRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLTextAreaElement>(null);

  const { data: history } = useGetChatHistory();

  const send = useSendChatMessage({
    mutation: {
      onSuccess: (data) => {
        setOptimisticMessages([]);
        queryClient.invalidateQueries({ queryKey: getGetChatHistoryQueryKey() });
      }
    }
  });

  const allMessages = [...(history ?? []), ...optimisticMessages];

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [allMessages.length]);

  const handleSend = () => {
    const msg = input.trim();
    if (!msg || send.isPending) return;
    setInput("");
    const now = new Date().toISOString();
    setOptimisticMessages(p => [
      ...p,
      { id: Date.now(), role: "user", content: msg, createdAt: now },
      { id: Date.now() + 1, role: "assistant", content: "...", createdAt: now },
    ]);
    send.mutate({ data: { message: msg } });
  };

  const handleKey = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  return (
    <Layout>
      <div className="flex flex-col h-full">
        <div className="px-6 py-4 border-b border-border bg-card/50">
          <div className="flex items-center gap-3 max-w-3xl mx-auto">
            <div className="p-2 bg-primary/10 rounded-xl">
              <Bot className="h-5 w-5 text-primary" />
            </div>
            <div>
              <h1 className="font-bold">RCL AI Assistant</h1>
              <p className="text-xs text-muted-foreground">Ask questions about moderation, procedures, and rules</p>
            </div>
          </div>
        </div>

        <div className="flex-1 overflow-y-auto px-4 py-6">
          <div className="max-w-3xl mx-auto space-y-4">
            {allMessages.length === 0 && (
              <div className="text-center py-16">
                <Bot className="h-12 w-12 mx-auto mb-3 text-primary/30" />
                <p className="font-semibold text-muted-foreground">How can I help you?</p>
                <p className="text-sm text-muted-foreground mt-1">Ask about moderation procedures, server rules, or escalation protocols.</p>
                <div className="mt-6 flex flex-wrap gap-2 justify-center">
                  {["What should a Trial Mod do first?", "How do I escalate a ban appeal?", "What's the punishment for spamming?"].map(s => (
                    <button
                      key={s}
                      onClick={() => { setInput(s); inputRef.current?.focus(); }}
                      className="px-3 py-1.5 text-xs bg-card border border-card-border rounded-full hover:border-primary/30 hover:text-primary transition-colors"
                    >
                      {s}
                    </button>
                  ))}
                </div>
              </div>
            )}

            <AnimatePresence>
              {allMessages.map((msg, i) => {
                const isUser = msg.role === "user";
                const isLoading = msg.content === "..." && msg.role === "assistant";
                return (
                  <motion.div
                    key={msg.id}
                    data-testid={`chat-message-${i}`}
                    initial={{ opacity: 0, y: 8 }}
                    animate={{ opacity: 1, y: 0 }}
                    className={`flex gap-3 ${isUser ? "flex-row-reverse" : ""}`}
                  >
                    <div className="flex-shrink-0 mt-1">
                      {isUser ? (
                        <img
                          src={getAvatarUrl(user?.discordId ?? "", user?.avatar)}
                          alt={user?.username}
                          className="h-8 w-8 rounded-full border border-border"
                        />
                      ) : (
                        <div className="h-8 w-8 rounded-full bg-primary/10 border border-primary/20 flex items-center justify-center">
                          <Bot className="h-4 w-4 text-primary" />
                        </div>
                      )}
                    </div>
                    <div className={`max-w-[75%] rounded-2xl px-4 py-3 text-sm leading-relaxed ${
                      isUser
                        ? "bg-primary text-primary-foreground rounded-tr-sm"
                        : "bg-card border border-card-border rounded-tl-sm"
                    }`}>
                      {isLoading ? (
                        <div className="flex gap-1 items-center h-4">
                          {[0, 0.2, 0.4].map((d, i) => (
                            <motion.span
                              key={i}
                              className="h-1.5 w-1.5 rounded-full bg-muted-foreground"
                              animate={{ opacity: [0.3, 1, 0.3] }}
                              transition={{ duration: 1, delay: d, repeat: Infinity }}
                            />
                          ))}
                        </div>
                      ) : (
                        <p className="whitespace-pre-wrap">{msg.content}</p>
                      )}
                    </div>
                  </motion.div>
                );
              })}
            </AnimatePresence>
            <div ref={bottomRef} />
          </div>
        </div>

        <div className="px-4 py-4 border-t border-border bg-card/30">
          <div className="max-w-3xl mx-auto flex gap-3 items-end">
            <textarea
              ref={inputRef}
              data-testid="input-chat-message"
              value={input}
              onChange={e => setInput(e.target.value)}
              onKeyDown={handleKey}
              placeholder="Ask about procedures, rules, or what to do in a situation..."
              rows={1}
              className="flex-1 px-4 py-3 bg-card border border-input rounded-xl text-sm focus:outline-none focus:ring-1 focus:ring-ring resize-none max-h-32"
              style={{ minHeight: "44px" }}
            />
            <button
              data-testid="button-send-message"
              onClick={handleSend}
              disabled={!input.trim() || send.isPending}
              className="p-3 bg-primary text-primary-foreground rounded-xl hover:bg-primary/90 disabled:opacity-50 transition-all active:scale-95 flex-shrink-0"
            >
              <Send className="h-4 w-4" />
            </button>
          </div>
          <p className="text-xs text-center text-muted-foreground mt-2">Press Enter to send, Shift+Enter for new line</p>
        </div>
      </div>
    </Layout>
  );
}
