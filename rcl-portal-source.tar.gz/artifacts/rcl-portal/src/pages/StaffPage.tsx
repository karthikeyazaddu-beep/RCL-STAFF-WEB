import { useState } from "react";
import { useListStaff, useCreateStaffProfile, useDeleteStaffProfile, getListStaffQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Layout } from "@/components/Layout";
import { RoleBadge } from "@/components/RoleBadge";
import { useAuth } from "@/contexts/AuthContext";
import { getAvatarUrl, isHicomPlus } from "@/lib/utils";
import { Plus, Trash2, User } from "lucide-react";
import { Link } from "wouter";
import { motion } from "framer-motion";

const ROLES = [
  { value: "trial_mod", label: "Trial Mod" },
  { value: "moderator", label: "Moderator" },
  { value: "senior_mod", label: "Senior Mod" },
  { value: "head_mod", label: "Head Mod" },
  { value: "hicom", label: "HICOM" },
];

export default function StaffPage() {
  const { user } = useAuth();
  const queryClient = useQueryClient();
  const { data: staff, isLoading } = useListStaff();
  const [showAdd, setShowAdd] = useState(false);
  const [form, setForm] = useState({ discordId: "", username: "", avatar: "", timezone: "", about: "", role: "trial_mod" });

  const invalidate = () => queryClient.invalidateQueries({ queryKey: getListStaffQueryKey() });

  const create = useCreateStaffProfile({ mutation: { onSuccess: () => { invalidate(); setShowAdd(false); setForm({ discordId: "", username: "", avatar: "", timezone: "", about: "", role: "trial_mod" }); } } });
  const remove = useDeleteStaffProfile({ mutation: { onSuccess: invalidate } });

  const canManage = isHicomPlus(user?.role ?? "none");

  return (
    <Layout>
      <div className="p-6 max-w-5xl mx-auto">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="text-2xl font-bold">Staff Directory</h1>
            <p className="text-muted-foreground text-sm mt-1">{staff?.length ?? 0} staff members</p>
          </div>
          {canManage && (
            <button
              data-testid="button-add-staff"
              onClick={() => setShowAdd(true)}
              className="flex items-center gap-2 px-4 py-2 bg-primary text-primary-foreground rounded-lg text-sm font-semibold hover:bg-primary/90 transition-colors"
            >
              <Plus className="h-4 w-4" />
              Add Profile
            </button>
          )}
        </div>

        {isLoading ? (
          <div className="flex justify-center py-16">
            <div className="h-8 w-8 border-2 border-primary border-t-transparent rounded-full animate-spin" />
          </div>
        ) : staff && staff.length > 0 ? (
          <motion.div
            className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4"
            initial="hidden" animate="show"
            variants={{ hidden: {}, show: { transition: { staggerChildren: 0.05 } } }}
          >
            {staff.map(s => (
              <motion.div
                key={s.id}
                data-testid={`staff-card-${s.id}`}
                variants={{ hidden: { opacity: 0, scale: 0.96 }, show: { opacity: 1, scale: 1 } }}
                className="bg-card border border-card-border rounded-xl p-5 hover:border-primary/30 transition-colors group"
              >
                <div className="flex items-start justify-between mb-4">
                  <Link href={`/staff/${s.id}`}>
                    <img
                      src={getAvatarUrl(s.discordId, s.avatar)}
                      alt={s.username}
                      className="h-12 w-12 rounded-full border-2 border-border group-hover:border-primary/40 transition-colors cursor-pointer"
                    />
                  </Link>
                  {canManage && (
                    <button
                      data-testid={`button-delete-staff-${s.id}`}
                      onClick={() => remove.mutate({ id: s.id })}
                      className="opacity-0 group-hover:opacity-100 p-1.5 text-muted-foreground hover:text-destructive hover:bg-destructive/10 rounded transition-all"
                    >
                      <Trash2 className="h-3.5 w-3.5" />
                    </button>
                  )}
                </div>
                <Link href={`/staff/${s.id}`}>
                  <div className="cursor-pointer">
                    <p data-testid={`text-staff-username-${s.id}`} className="font-semibold hover:text-primary transition-colors">{s.username}</p>
                    <p className="text-xs text-muted-foreground font-mono mt-0.5 mb-2">{s.discordId}</p>
                    <RoleBadge role={s.role} size="xs" />
                    {s.timezone && <p className="text-xs text-muted-foreground mt-2">{s.timezone}</p>}
                    {s.about && <p className="text-xs text-muted-foreground mt-1 line-clamp-2">{s.about}</p>}
                  </div>
                </Link>
              </motion.div>
            ))}
          </motion.div>
        ) : (
          <div className="text-center py-16 text-muted-foreground">
            <User className="h-10 w-10 mx-auto mb-3 opacity-30" />
            <p>No staff profiles yet.</p>
            {canManage && <p className="text-sm mt-1">Add the first profile using the button above.</p>}
          </div>
        )}
      </div>

      {/* Add Staff Modal */}
      {showAdd && (
        <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center px-4"
          onClick={(e) => e.target === e.currentTarget && setShowAdd(false)}>
          <motion.div
            initial={{ scale: 0.95, opacity: 0 }} animate={{ scale: 1, opacity: 1 }}
            className="bg-card border border-card-border rounded-xl p-6 w-full max-w-md shadow-2xl max-h-[90vh] overflow-y-auto"
          >
            <h3 className="font-bold text-lg mb-4">Add Staff Profile</h3>
            <div className="space-y-3">
              {[
                { key: "discordId", label: "Discord ID", placeholder: "123456789012345678", required: true },
                { key: "username", label: "Username", placeholder: "username", required: true },
                { key: "avatar", label: "Avatar Hash (optional)", placeholder: "abc123..." },
                { key: "timezone", label: "Timezone", placeholder: "UTC+0, EST, etc." },
              ].map(f => (
                <div key={f.key}>
                  <label className="text-xs font-medium text-muted-foreground uppercase tracking-wider">{f.label}</label>
                  <input
                    data-testid={`input-${f.key}`}
                    value={form[f.key as keyof typeof form]}
                    onChange={e => setForm(p => ({ ...p, [f.key]: e.target.value }))}
                    placeholder={f.placeholder}
                    className="mt-1 w-full px-3 py-2 bg-muted/50 border border-input rounded-lg text-sm focus:outline-none focus:ring-1 focus:ring-ring"
                  />
                </div>
              ))}
              <div>
                <label className="text-xs font-medium text-muted-foreground uppercase tracking-wider">About</label>
                <textarea
                  data-testid="input-about"
                  value={form.about}
                  onChange={e => setForm(p => ({ ...p, about: e.target.value }))}
                  placeholder="Brief description..."
                  rows={2}
                  className="mt-1 w-full px-3 py-2 bg-muted/50 border border-input rounded-lg text-sm focus:outline-none focus:ring-1 focus:ring-ring resize-none"
                />
              </div>
              <div>
                <label className="text-xs font-medium text-muted-foreground uppercase tracking-wider">Role</label>
                <select
                  data-testid="select-role"
                  value={form.role}
                  onChange={e => setForm(p => ({ ...p, role: e.target.value }))}
                  className="mt-1 w-full px-3 py-2 bg-muted/50 border border-input rounded-lg text-sm focus:outline-none focus:ring-1 focus:ring-ring"
                >
                  {ROLES.map(r => <option key={r.value} value={r.value}>{r.label}</option>)}
                </select>
              </div>
            </div>
            <div className="flex gap-3 mt-5">
              <button onClick={() => setShowAdd(false)} className="flex-1 py-2 border border-border rounded-lg text-sm hover:bg-accent transition-colors">Cancel</button>
              <button
                data-testid="button-create-staff"
                onClick={() => create.mutate({ data: { discordId: form.discordId, username: form.username, avatar: form.avatar || null, timezone: form.timezone || null, about: form.about || null, role: form.role as any } })}
                disabled={create.isPending || !form.discordId || !form.username}
                className="flex-1 py-2 bg-primary text-primary-foreground rounded-lg text-sm font-semibold hover:bg-primary/90 disabled:opacity-60 transition-colors"
              >
                {create.isPending ? "Creating..." : "Create Profile"}
              </button>
            </div>
          </motion.div>
        </div>
      )}
    </Layout>
  );
}
