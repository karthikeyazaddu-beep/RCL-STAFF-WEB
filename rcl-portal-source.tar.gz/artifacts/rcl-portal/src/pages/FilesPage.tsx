import { useRef, useState } from "react";
import { useListFiles, useDeleteFile, getListFilesQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Layout } from "@/components/Layout";
import { useAuth } from "@/contexts/AuthContext";
import { isHicomPlus, formatDate, formatFileSize } from "@/lib/utils";
import { Upload, FileText, Trash2, Download, FilePlus } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

const mimeIcon: Record<string, string> = {
  "application/pdf": "PDF",
  "text/plain": "TXT",
  "image/png": "PNG",
  "image/jpeg": "JPG",
};

export default function FilesPage() {
  const { user } = useAuth();
  const queryClient = useQueryClient();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [uploading, setUploading] = useState(false);
  const [uploadError, setUploadError] = useState("");

  const { data: files, isLoading } = useListFiles();
  const remove = useDeleteFile({ mutation: { onSuccess: () => queryClient.invalidateQueries({ queryKey: getListFilesQueryKey() }) } });

  const canManage = isHicomPlus(user?.role ?? "none");

  const handleUpload = async (file: File) => {
    setUploading(true);
    setUploadError("");
    try {
      const fd = new FormData();
      fd.append("file", file);
      const res = await fetch("/api/files/upload", { method: "POST", body: fd, credentials: "include" });
      if (!res.ok) {
        const err = await res.json().catch(() => ({ error: "Upload failed" }));
        setUploadError(err.error ?? "Upload failed");
      } else {
        queryClient.invalidateQueries({ queryKey: getListFilesQueryKey() });
      }
    } catch {
      setUploadError("Network error. Please try again.");
    } finally {
      setUploading(false);
      if (fileInputRef.current) fileInputRef.current.value = "";
    }
  };

  const getMimeLabel = (mime: string, name: string) => {
    if (mimeIcon[mime]) return mimeIcon[mime];
    const ext = name.split(".").pop()?.toUpperCase() ?? "FILE";
    return ext.slice(0, 4);
  };

  return (
    <Layout>
      <div className="p-6 max-w-4xl mx-auto">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="text-2xl font-bold">Files</h1>
            <p className="text-muted-foreground text-sm mt-1">Staff documents and resources</p>
          </div>
          {canManage && (
            <div>
              <input
                ref={fileInputRef}
                type="file"
                className="hidden"
                data-testid="input-file-upload"
                onChange={e => { const f = e.target.files?.[0]; if (f) handleUpload(f); }}
              />
              <button
                data-testid="button-upload-file"
                onClick={() => fileInputRef.current?.click()}
                disabled={uploading}
                className="flex items-center gap-2 px-4 py-2 bg-primary text-primary-foreground rounded-lg text-sm font-semibold hover:bg-primary/90 disabled:opacity-60 transition-colors"
              >
                <Upload className="h-4 w-4" />
                {uploading ? "Uploading..." : "Upload File"}
              </button>
            </div>
          )}
        </div>

        {uploadError && (
          <div className="mb-4 px-4 py-3 bg-destructive/10 border border-destructive/30 rounded-lg text-sm text-destructive">
            {uploadError}
          </div>
        )}

        {isLoading ? (
          <div className="flex justify-center py-16">
            <div className="h-8 w-8 border-2 border-primary border-t-transparent rounded-full animate-spin" />
          </div>
        ) : files && files.length > 0 ? (
          <motion.div className="space-y-2" initial="hidden" animate="show"
            variants={{ hidden: {}, show: { transition: { staggerChildren: 0.04 } } }}>
            <AnimatePresence>
              {files.map(file => (
                <motion.div
                  key={file.id}
                  data-testid={`file-item-${file.id}`}
                  variants={{ hidden: { opacity: 0, x: -8 }, show: { opacity: 1, x: 0 } }}
                  exit={{ opacity: 0, x: 20 }}
                  className="flex items-center gap-4 bg-card border border-card-border rounded-xl px-5 py-4 hover:border-primary/30 transition-colors group"
                >
                  <div className="flex-shrink-0 w-10 h-10 bg-primary/10 border border-primary/20 rounded-lg flex items-center justify-center">
                    <span className="text-xs font-bold text-primary">{getMimeLabel(file.mimeType, file.originalName ?? "")}</span>
                  </div>

                  <div className="flex-1 min-w-0">
                    <p data-testid={`text-filename-${file.id}`} className="font-medium text-sm truncate">{file.originalName}</p>
                    <div className="flex items-center gap-3 text-xs text-muted-foreground mt-0.5">
                      <span>{formatFileSize(file.size)}</span>
                      <span>&middot;</span>
                      <span>{formatDate(file.createdAt)}</span>
                      {file.description && (
                        <>
                          <span>&middot;</span>
                          <span className="truncate max-w-xs">{file.description}</span>
                        </>
                      )}
                    </div>
                  </div>

                  <div className="flex items-center gap-2 flex-shrink-0">
                    <a
                      data-testid={`button-download-${file.id}`}
                      href={`/api/files/${file.id}/download`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-center gap-1.5 px-3 py-1.5 bg-primary/10 hover:bg-primary/20 text-primary text-xs font-medium rounded-lg transition-colors"
                    >
                      <Download className="h-3.5 w-3.5" />
                      Open
                    </a>
                    {canManage && (
                      <button
                        data-testid={`button-delete-file-${file.id}`}
                        onClick={() => remove.mutate({ id: file.id })}
                        className="opacity-0 group-hover:opacity-100 p-1.5 text-muted-foreground hover:text-destructive hover:bg-destructive/10 rounded transition-all"
                      >
                        <Trash2 className="h-3.5 w-3.5" />
                      </button>
                    )}
                  </div>
                </motion.div>
              ))}
            </AnimatePresence>
          </motion.div>
        ) : (
          <div className="text-center py-16 text-muted-foreground">
            <FilePlus className="h-10 w-10 mx-auto mb-3 opacity-30" />
            <p>No files uploaded yet.</p>
            {canManage && <p className="text-sm mt-1">Upload the first document using the button above.</p>}
          </div>
        )}
      </div>
    </Layout>
  );
}
