import { clsx, type ClassValue } from "clsx"
import { twMerge } from "tailwind-merge"

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

export function getAvatarUrl(discordId: string, avatar: string | null | undefined): string {
  if (avatar) return `https://cdn.discordapp.com/avatars/${discordId}/${avatar}.png?size=128`;
  return `https://cdn.discordapp.com/embed/avatars/0.png`;
}

export function getRoleLabel(role: string): string {
  const labels: Record<string, string> = {
    owner: "Owner",
    hicom: "HICOM",
    head_mod: "Head Mod",
    senior_mod: "Senior Mod",
    moderator: "Moderator",
    trial_mod: "Trial Mod",
    pending: "Pending",
    none: "None",
  };
  return labels[role] ?? role;
}

export function formatDate(iso: string): string {
  return new Date(iso).toLocaleDateString("en-US", {
    year: "numeric", month: "short", day: "numeric",
  });
}

export function formatFileSize(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

export function isHicomPlus(role: string): boolean {
  return ["owner", "hicom"].includes(role);
}

export function isApproved(status: string, role: string): boolean {
  return status === "approved" || role === "owner";
}

