import { createContext, useContext, ReactNode } from "react";
import { useGetMe } from "@workspace/api-client-react";

type User = {
  discordId: string;
  username: string;
  discriminator: string | null;
  avatar: string | null;
  role: string;
  status: string;
  blacklistedUntil: string | null;
};

type AuthContextType = {
  user: User | null;
  isLoading: boolean;
  isAuthenticated: boolean;
};

const AuthContext = createContext<AuthContextType>({
  user: null,
  isLoading: true,
  isAuthenticated: false,
});

export function AuthProvider({ children }: { children: ReactNode }) {
  const { data, isLoading, error } = useGetMe({
    query: { retry: false, staleTime: 30_000, queryKey: ["/api/auth/me"] } as any
  });

  const user = (!isLoading && !error && data) ? data as User : null;

  return (
    <AuthContext.Provider value={{ user, isLoading, isAuthenticated: !!user }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  return useContext(AuthContext);
}
