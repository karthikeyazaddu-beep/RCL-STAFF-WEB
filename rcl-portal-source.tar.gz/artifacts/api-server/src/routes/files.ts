import { Router, type IRouter } from "express";
import { db, filesTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import { requireApproved, requireHicom } from "../lib/auth";
import multer from "multer";
import path from "path";
import fs from "fs";

const UPLOADS_DIR = path.join(process.cwd(), "uploads");
if (!fs.existsSync(UPLOADS_DIR)) {
  fs.mkdirSync(UPLOADS_DIR, { recursive: true });
}

const storage = multer.diskStorage({
  destination: (_req, _file, cb) => cb(null, UPLOADS_DIR),
  filename: (_req, file, cb) => {
    const unique = `${Date.now()}-${Math.round(Math.random() * 1e9)}`;
    cb(null, `${unique}${path.extname(file.originalname)}`);
  },
});

const upload = multer({
  storage,
  limits: { fileSize: 50 * 1024 * 1024 },
});

const router: IRouter = Router();

router.get("/files", requireApproved, async (req, res): Promise<void> => {
  const files = await db.select().from(filesTable).orderBy(filesTable.createdAt);
  res.json(files.map(f => ({
    ...f,
    createdAt: f.createdAt.toISOString(),
  })));
});

router.post("/files/upload", requireHicom, upload.single("file"), async (req, res): Promise<void> => {
  if (!req.file) {
    res.status(400).json({ error: "No file uploaded" });
    return;
  }

  const description = req.body.description as string | undefined;

  const [record] = await db.insert(filesTable).values({
    name: req.file.filename,
    originalName: req.file.originalname,
    mimeType: req.file.mimetype,
    size: req.file.size,
    filePath: req.file.path,
    uploadedBy: req.session.discordId!,
    description: description ?? null,
  }).returning();

  res.status(201).json({
    ...record,
    createdAt: record.createdAt.toISOString(),
  });
});

router.get("/files/:id", requireApproved, async (req, res): Promise<void> => {
  const rawId = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
  const id = parseInt(rawId, 10);

  const [file] = await db.select().from(filesTable).where(eq(filesTable.id, id));
  if (!file) {
    res.status(404).json({ error: "File not found" });
    return;
  }

  res.json({ ...file, createdAt: file.createdAt.toISOString() });
});

router.get("/files/:id/download", requireApproved, async (req, res): Promise<void> => {
  const rawId = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
  const id = parseInt(rawId, 10);

  const [file] = await db.select().from(filesTable).where(eq(filesTable.id, id));
  if (!file) {
    res.status(404).json({ error: "File not found" });
    return;
  }

  if (!fs.existsSync(file.filePath)) {
    res.status(404).json({ error: "File not found on disk" });
    return;
  }

  res.setHeader("Content-Disposition", `inline; filename="${file.originalName}"`);
  res.setHeader("Content-Type", file.mimeType);
  res.sendFile(file.filePath);
});

router.delete("/files/:id", requireHicom, async (req, res): Promise<void> => {
  const rawId = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
  const id = parseInt(rawId, 10);

  const [file] = await db.delete(filesTable).where(eq(filesTable.id, id)).returning();
  if (!file) {
    res.status(404).json({ error: "File not found" });
    return;
  }

  if (fs.existsSync(file.filePath)) {
    fs.unlinkSync(file.filePath);
  }

  res.sendStatus(204);
});

export default router;
