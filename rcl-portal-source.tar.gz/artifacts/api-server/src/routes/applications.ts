import { Router, type IRouter } from "express";
import { db, applicationsTable, usersTable } from "@workspace/db";
import { eq, count, and } from "drizzle-orm";
import { requireAuth, requireHicom, requireApproved } from "../lib/auth";

const router: IRouter = Router();

router.get("/applications", requireHicom, async (req, res): Promise<void> => {
  const apps = await db.select().from(applicationsTable).orderBy(applicationsTable.createdAt);
  res.json(apps.map(a => ({
    ...a,
    blacklistedUntil: a.blacklistedUntil?.toISOString() ?? null,
    createdAt: a.createdAt.toISOString(),
    updatedAt: a.updatedAt?.toISOString() ?? null,
  })));
});

router.get("/applications/stats", requireApproved, async (req, res): Promise<void> => {
  const rows = await db.select({
    status: applicationsTable.status,
    cnt: count(),
  }).from(applicationsTable).groupBy(applicationsTable.status);

  const stats = { total: 0, pending: 0, approved: 0, declined: 0, blacklisted: 0 };
  for (const row of rows) {
    const n = Number(row.cnt);
    stats.total += n;
    if (row.status === "pending") stats.pending = n;
    if (row.status === "approved") stats.approved = n;
    if (row.status === "declined") stats.declined = n;
    if (row.status === "blacklisted") stats.blacklisted = n;
  }
  res.json(stats);
});

router.get("/applications/my", requireAuth, async (req, res): Promise<void> => {
  const discordId = req.session.discordId!;
  const [app] = await db.select().from(applicationsTable)
    .where(eq(applicationsTable.discordId, discordId))
    .orderBy(applicationsTable.createdAt)
    .limit(1);

  if (!app) {
    res.status(404).json({ error: "No application found" });
    return;
  }

  res.json({
    ...app,
    blacklistedUntil: app.blacklistedUntil?.toISOString() ?? null,
    createdAt: app.createdAt.toISOString(),
    updatedAt: app.updatedAt?.toISOString() ?? null,
  });
});

router.post("/applications", requireAuth, async (req, res): Promise<void> => {
  const discordId = req.session.discordId!;

  const [user] = await db.select().from(usersTable).where(eq(usersTable.discordId, discordId));

  if (user?.status === "blacklisted" && user.blacklistedUntil && user.blacklistedUntil > new Date()) {
    res.status(403).json({ error: "You are blacklisted until " + user.blacklistedUntil.toISOString() });
    return;
  }

  const [existing] = await db.select().from(applicationsTable)
    .where(and(eq(applicationsTable.discordId, discordId), eq(applicationsTable.status, "pending")));

  if (existing) {
    res.status(409).json({ error: "You already have a pending application" });
    return;
  }

  const [app] = await db.insert(applicationsTable).values({
    discordId,
    username: req.session.username!,
    discriminator: req.session.discriminator,
    avatar: req.session.avatar,
    status: "pending",
  }).returning();

  res.status(201).json({
    ...app,
    blacklistedUntil: app.blacklistedUntil?.toISOString() ?? null,
    createdAt: app.createdAt.toISOString(),
    updatedAt: app.updatedAt?.toISOString() ?? null,
  });
});

router.post("/applications/:id/approve", requireHicom, async (req, res): Promise<void> => {
  const rawId = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
  const id = parseInt(rawId, 10);
  const { role } = req.body as { role: string };

  const validRoles = ["trial_mod", "moderator", "senior_mod", "head_mod", "hicom"];
  if (!validRoles.includes(role)) {
    res.status(400).json({ error: "Invalid role" });
    return;
  }

  const [app] = await db.update(applicationsTable).set({
    status: "approved",
    role,
    reviewedBy: req.session.discordId,
  }).where(eq(applicationsTable.id, id)).returning();

  if (!app) {
    res.status(404).json({ error: "Application not found" });
    return;
  }

  await db.update(usersTable).set({
    status: "approved",
    role: role as any,
  }).where(eq(usersTable.discordId, app.discordId));

  res.json({
    ...app,
    blacklistedUntil: app.blacklistedUntil?.toISOString() ?? null,
    createdAt: app.createdAt.toISOString(),
    updatedAt: app.updatedAt?.toISOString() ?? null,
  });
});

router.post("/applications/:id/decline", requireHicom, async (req, res): Promise<void> => {
  const rawId = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
  const id = parseInt(rawId, 10);

  const [app] = await db.update(applicationsTable).set({
    status: "declined",
    reviewedBy: req.session.discordId,
  }).where(eq(applicationsTable.id, id)).returning();

  if (!app) {
    res.status(404).json({ error: "Application not found" });
    return;
  }

  await db.update(usersTable).set({ status: "declined" }).where(eq(usersTable.discordId, app.discordId));

  res.json({
    ...app,
    blacklistedUntil: app.blacklistedUntil?.toISOString() ?? null,
    createdAt: app.createdAt.toISOString(),
    updatedAt: app.updatedAt?.toISOString() ?? null,
  });
});

router.post("/applications/:id/blacklist", requireHicom, async (req, res): Promise<void> => {
  const rawId = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
  const id = parseInt(rawId, 10);

  const blacklistedUntil = new Date(Date.now() + 10 * 24 * 60 * 60 * 1000);

  const [app] = await db.update(applicationsTable).set({
    status: "blacklisted",
    blacklistedUntil,
    reviewedBy: req.session.discordId,
  }).where(eq(applicationsTable.id, id)).returning();

  if (!app) {
    res.status(404).json({ error: "Application not found" });
    return;
  }

  await db.update(usersTable).set({
    status: "blacklisted",
    blacklistedUntil,
  }).where(eq(usersTable.discordId, app.discordId));

  res.json({
    ...app,
    blacklistedUntil: app.blacklistedUntil?.toISOString() ?? null,
    createdAt: app.createdAt.toISOString(),
    updatedAt: app.updatedAt?.toISOString() ?? null,
  });
});

export default router;
