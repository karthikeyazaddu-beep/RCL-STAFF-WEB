import { Router, type IRouter } from "express";
import { db, chatMessagesTable, filesTable, botContextTable } from "@workspace/db";
import { eq, desc } from "drizzle-orm";
import { requireApproved } from "../lib/auth";
import { logger } from "../lib/logger";
import OpenAI from "openai";
import fs from "fs";

const router: IRouter = Router();

const openai = new OpenAI({
  baseURL: "https://openrouter.ai/api/v1",
  apiKey: process.env.OPENROUTER_API_KEY || "",
  defaultHeaders: {
    "HTTP-Referer": "https://rcl-portal.replit.app",
    "X-Title": "RCL Staff Portal",
  },
});

async function buildSystemPrompt(): Promise<string> {
  const base = `You are an AI assistant for the RCL Discord staff team. You help staff members — especially Trial Moderators — understand rules, procedures, and best practices for moderation.

Role hierarchy: Owner > HICOM > Head Mod > Senior Mod > Moderator > Trial Mod.

General guidance:
- Trial Mods should always escalate serious issues to Senior Mods or higher
- When in doubt about a punishment, consult a higher rank
- Always document your moderation actions
- Be professional and fair in all moderation decisions
- Zero tolerance for staff misconduct

Key principles:
1. Consistency: Apply rules the same way for all members
2. Proportionality: Punishment should fit the offense
3. Documentation: Always log major actions
4. Escalation: Know when to involve higher staff

If you have specific questions about server rules or procedures, you can find uploaded documents in the staff portal's Files section.`;

  try {
    let extra = "";

    // Owner-entered context entries (highest priority)
    const contextEntries = await db.select().from(botContextTable).orderBy(botContextTable.createdAt);
    if (contextEntries.length > 0) {
      extra += "\n\n=== CUSTOM INSTRUCTIONS FROM STAFF LEADERSHIP ===";
      for (const entry of contextEntries) {
        extra += `\n\n[${entry.title}]\n${entry.content}`;
      }
      extra += "\n=== END CUSTOM INSTRUCTIONS ===";
    }

    // Supplementary context from uploaded text files
    const files = await db.select().from(filesTable).orderBy(filesTable.createdAt);
    const textFiles = files.filter(f =>
      f.mimeType.startsWith("text/") || f.originalName.endsWith(".txt") || f.originalName.endsWith(".md")
    );

    for (const file of textFiles.slice(0, 3)) {
      try {
        if (fs.existsSync(file.filePath)) {
          const content = fs.readFileSync(file.filePath, "utf-8").slice(0, 3000);
          extra += `\n\n--- Document: ${file.originalName} ---\n${content}`;
        }
      } catch {
        // skip unreadable files
      }
    }

    return base + extra;
  } catch {
    return base;
  }
}

router.post("/chat/message", requireApproved, async (req, res): Promise<void> => {
  const { message } = req.body as { message: string };
  if (!message || typeof message !== "string") {
    res.status(400).json({ error: "Message is required" });
    return;
  }

  const discordId = req.session.discordId!;

  await db.insert(chatMessagesTable).values({
    discordId,
    role: "user",
    content: message,
  });

  try {
    const systemPrompt = await buildSystemPrompt();

    const history = await db.select().from(chatMessagesTable)
      .where(eq(chatMessagesTable.discordId, discordId))
      .orderBy(desc(chatMessagesTable.createdAt))
      .limit(20);

    const messages = history.reverse().map(m => ({
      role: m.role as "user" | "assistant",
      content: m.content,
    }));

    const completion = await openai.chat.completions.create({
      model: "openai/gpt-4o-mini",
      messages: [
        { role: "system", content: systemPrompt },
        ...messages,
      ],
      max_tokens: 1000,
    });

    const reply = completion.choices[0]?.message?.content ?? "I'm sorry, I couldn't generate a response. Please try again.";

    const [saved] = await db.insert(chatMessagesTable).values({
      discordId,
      role: "assistant",
      content: reply,
    }).returning();

    res.json({ reply, messageId: saved.id });
  } catch (err) {
    logger.error({ err }, "AI chat error");
    const [saved] = await db.insert(chatMessagesTable).values({
      discordId,
      role: "assistant",
      content: "I'm currently unavailable. Please try again later or ask a senior staff member.",
    }).returning();
    res.json({ reply: "I'm currently unavailable. Please try again later or ask a senior staff member.", messageId: saved.id });
  }
});

router.get("/chat/history", requireApproved, async (req, res): Promise<void> => {
  const discordId = req.session.discordId!;

  const messages = await db.select().from(chatMessagesTable)
    .where(eq(chatMessagesTable.discordId, discordId))
    .orderBy(chatMessagesTable.createdAt)
    .limit(100);

  res.json(messages.map(m => ({
    ...m,
    createdAt: m.createdAt.toISOString(),
  })));
});

export default router;
