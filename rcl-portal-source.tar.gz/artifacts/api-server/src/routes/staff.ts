import { Router, type IRouter } from "express";
import { db, staffProfilesTable, usersTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import { requireApproved, requireHicom, requireOwner } from "../lib/auth";

const router: IRouter = Router();

router.get("/staff", requireApproved, async (req, res): Promise<void> => {
  const profiles = await db.select().from(staffProfilesTable).orderBy(staffProfilesTable.createdAt);
  res.json(profiles.map(p => ({
    ...p,
    createdAt: p.createdAt.toISOString(),
    updatedAt: p.updatedAt?.toISOString() ?? null,
  })));
});

router.post("/staff", requireHicom, async (req, res): Promise<void> => {
  const { discordId, username, avatar, timezone, about, role } = req.body as {
    discordId: string;
    username: string;
    avatar?: string;
    timezone?: string;
    about?: string;
    role: string;
  };

  const validRoles = ["hicom", "head_mod", "senior_mod", "moderator", "trial_mod"];
  if (!validRoles.includes(role)) {
    res.status(400).json({ error: "Invalid role" });
    return;
  }

  const [profile] = await db.insert(staffProfilesTable).values({
    discordId,
    username,
    avatar: avatar ?? null,
    timezone: timezone ?? null,
    about: about ?? null,
    role,
  }).returning();

  res.status(201).json({
    ...profile,
    createdAt: profile.createdAt.toISOString(),
    updatedAt: profile.updatedAt?.toISOString() ?? null,
  });
});

router.get("/staff/:id", requireApproved, async (req, res): Promise<void> => {
  const rawId = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
  const id = parseInt(rawId, 10);

  const [profile] = await db.select().from(staffProfilesTable).where(eq(staffProfilesTable.id, id));
  if (!profile) {
    res.status(404).json({ error: "Staff profile not found" });
    return;
  }

  res.json({
    ...profile,
    createdAt: profile.createdAt.toISOString(),
    updatedAt: profile.updatedAt?.toISOString() ?? null,
  });
});

router.patch("/staff/:id", requireHicom, async (req, res): Promise<void> => {
  const rawId = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
  const id = parseInt(rawId, 10);

  const { username, avatar, timezone, about, role } = req.body as {
    username?: string;
    avatar?: string;
    timezone?: string;
    about?: string;
    role?: string;
  };

  const updateData: Record<string, any> = {};
  if (username != null) updateData.username = username;
  if (avatar !== undefined) updateData.avatar = avatar;
  if (timezone !== undefined) updateData.timezone = timezone;
  if (about !== undefined) updateData.about = about;
  if (role != null) {
    const validRoles = ["hicom", "head_mod", "senior_mod", "moderator", "trial_mod"];
    if (!validRoles.includes(role)) {
      res.status(400).json({ error: "Invalid role" });
      return;
    }
    updateData.role = role;
  }

  const [profile] = await db.update(staffProfilesTable).set(updateData).where(eq(staffProfilesTable.id, id)).returning();

  if (!profile) {
    res.status(404).json({ error: "Staff profile not found" });
    return;
  }

  res.json({
    ...profile,
    createdAt: profile.createdAt.toISOString(),
    updatedAt: profile.updatedAt?.toISOString() ?? null,
  });
});

router.delete("/staff/:id", requireHicom, async (req, res): Promise<void> => {
  const rawId = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
  const id = parseInt(rawId, 10);

  const [deleted] = await db.delete(staffProfilesTable).where(eq(staffProfilesTable.id, id)).returning();
  if (!deleted) {
    res.status(404).json({ error: "Staff profile not found" });
    return;
  }

  res.sendStatus(204);
});

router.patch("/staff/role/:userId", async (req, res): Promise<void> => {
  const discordId = req.session.discordId;
  if (!discordId) {
    res.status(401).json({ error: "Not authenticated" });
    return;
  }

  const [requester] = await db.select().from(usersTable).where(eq(usersTable.discordId, discordId));
  if (!requester) {
    res.status(403).json({ error: "Access denied" });
    return;
  }

  const targetUserId = Array.isArray(req.params.userId) ? req.params.userId[0] : req.params.userId;
  const { role } = req.body as { role: string };

  if (role === "hicom" && requester.role !== "owner") {
    res.status(403).json({ error: "Only the owner can grant HICOM role" });
    return;
  }

  if (!["owner", "hicom"].includes(requester.role)) {
    res.status(403).json({ error: "HICOM access required" });
    return;
  }

  const validRoles = ["hicom", "head_mod", "senior_mod", "moderator", "trial_mod"];
  if (!validRoles.includes(role)) {
    res.status(400).json({ error: "Invalid role" });
    return;
  }

  const [profile] = await db.update(staffProfilesTable).set({ role }).where(eq(staffProfilesTable.discordId, targetUserId)).returning();

  if (!profile) {
    res.status(404).json({ error: "Staff profile not found" });
    return;
  }

  await db.update(usersTable).set({ role: role as any }).where(eq(usersTable.discordId, targetUserId));

  res.json({
    ...profile,
    createdAt: profile.createdAt.toISOString(),
    updatedAt: profile.updatedAt?.toISOString() ?? null,
  });
});

export default router;
