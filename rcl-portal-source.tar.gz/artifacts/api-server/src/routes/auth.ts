import { Router, type IRouter } from "express";
import { db, usersTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import { logger } from "../lib/logger";

const router: IRouter = Router();

const DISCORD_CLIENT_ID = process.env.DISCORD_CLIENT_ID!;
const DISCORD_CLIENT_SECRET = process.env.DISCORD_CLIENT_SECRET!;
const OWNER_DISCORD_ID = process.env.OWNER_DISCORD_ID!;

function getRedirectUri(req: any): string {
  const proto = req.headers["x-forwarded-proto"] || req.protocol;
  const host = req.headers["x-forwarded-host"] || req.headers.host;
  return `${proto}://${host}/api/auth/callback`;
}

router.get("/auth/discord", (req, res): void => {
  const redirectUri = getRedirectUri(req);
  const params = new URLSearchParams({
    client_id: DISCORD_CLIENT_ID,
    redirect_uri: redirectUri,
    response_type: "code",
    scope: "identify",
  });
  res.redirect(`https://discord.com/api/oauth2/authorize?${params}`);
});

router.get("/auth/callback", async (req, res): Promise<void> => {
  const code = req.query.code as string;
  if (!code) {
    res.redirect("/?error=no_code");
    return;
  }

  try {
    const redirectUri = getRedirectUri(req);

    const tokenRes = await fetch("https://discord.com/api/oauth2/token", {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: new URLSearchParams({
        client_id: DISCORD_CLIENT_ID,
        client_secret: DISCORD_CLIENT_SECRET,
        grant_type: "authorization_code",
        code,
        redirect_uri: redirectUri,
      }),
    });

    if (!tokenRes.ok) {
      req.log.error({ status: tokenRes.status }, "Failed to exchange code for token");
      res.redirect("/?error=token_exchange");
      return;
    }

    const tokenData = await tokenRes.json() as { access_token: string };
    const accessToken = tokenData.access_token;

    const userRes = await fetch("https://discord.com/api/users/@me", {
      headers: { Authorization: `Bearer ${accessToken}` },
    });

    if (!userRes.ok) {
      req.log.error({ status: userRes.status }, "Failed to fetch Discord user");
      res.redirect("/?error=user_fetch");
      return;
    }

    const discordUser = await userRes.json() as {
      id: string;
      username: string;
      discriminator: string;
      avatar: string | null;
    };

    req.session.discordId = discordUser.id;
    req.session.username = discordUser.username;
    req.session.discriminator = discordUser.discriminator;
    req.session.avatar = discordUser.avatar ?? undefined;
    req.session.accessToken = accessToken;

    const isOwner = discordUser.id === OWNER_DISCORD_ID;

    const [existing] = await db.select().from(usersTable).where(eq(usersTable.discordId, discordUser.id));

    if (!existing) {
      await db.insert(usersTable).values({
        discordId: discordUser.id,
        username: discordUser.username,
        discriminator: discordUser.discriminator !== "0" ? discordUser.discriminator : null,
        avatar: discordUser.avatar,
        role: isOwner ? "owner" : "none",
        status: isOwner ? "approved" : "none",
      });
    } else {
      await db.update(usersTable).set({
        username: discordUser.username,
        discriminator: discordUser.discriminator !== "0" ? discordUser.discriminator : null,
        avatar: discordUser.avatar,
        ...(isOwner && existing.role === "none" ? { role: "owner", status: "approved" } : {}),
      }).where(eq(usersTable.discordId, discordUser.id));
    }

    res.redirect("/");
  } catch (err) {
    req.log.error({ err }, "OAuth callback error");
    res.redirect("/?error=internal");
  }
});

router.get("/auth/me", async (req, res): Promise<void> => {
  if (!req.session.discordId) {
    res.status(401).json({ error: "Not authenticated" });
    return;
  }

  const [user] = await db.select().from(usersTable).where(eq(usersTable.discordId, req.session.discordId));
  if (!user) {
    res.status(401).json({ error: "User not found" });
    return;
  }

  const now = new Date();
  if (user.status === "blacklisted" && user.blacklistedUntil && user.blacklistedUntil < now) {
    await db.update(usersTable).set({ status: "none", blacklistedUntil: null }).where(eq(usersTable.discordId, user.discordId));
    user.status = "none";
    user.blacklistedUntil = null;
  }

  res.json({
    discordId: user.discordId,
    username: user.username,
    discriminator: user.discriminator,
    avatar: user.avatar,
    role: user.role,
    status: user.status,
    blacklistedUntil: user.blacklistedUntil?.toISOString() ?? null,
  });
});

router.post("/auth/logout", (req, res): void => {
  req.session.destroy(() => {
    res.json({ success: true });
  });
});

export default router;
