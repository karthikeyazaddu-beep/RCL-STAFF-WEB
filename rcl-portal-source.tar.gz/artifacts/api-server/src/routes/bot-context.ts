import { Router, type IRouter } from "express";
import { db, botContextTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import { requireOwner } from "../lib/auth";

const router: IRouter = Router();

router.get("/bot-context", requireOwner, async (req, res): Promise<void> => {
  const entries = await db.select().from(botContextTable).orderBy(botContextTable.createdAt);
  res.json(entries.map(e => ({
    ...e,
    createdAt: e.createdAt.toISOString(),
    updatedAt: e.updatedAt?.toISOString() ?? null,
  })));
});

router.post("/bot-context", requireOwner, async (req, res): Promise<void> => {
  const { title, content } = req.body as { title: string; content: string };
  if (!title?.trim() || !content?.trim()) {
    res.status(400).json({ error: "Title and content are required" });
    return;
  }
  const [entry] = await db.insert(botContextTable).values({ title: title.trim(), content: content.trim() }).returning();
  res.status(201).json({ ...entry, createdAt: entry.createdAt.toISOString(), updatedAt: entry.updatedAt?.toISOString() ?? null });
});

router.patch("/bot-context/:id", requireOwner, async (req, res): Promise<void> => {
  const id = parseInt(Array.isArray(req.params.id) ? req.params.id[0] : req.params.id, 10);
  const { title, content } = req.body as { title: string; content: string };
  if (!title?.trim() || !content?.trim()) {
    res.status(400).json({ error: "Title and content are required" });
    return;
  }
  const [entry] = await db.update(botContextTable).set({ title: title.trim(), content: content.trim() }).where(eq(botContextTable.id, id)).returning();
  if (!entry) { res.status(404).json({ error: "Not found" }); return; }
  res.json({ ...entry, createdAt: entry.createdAt.toISOString(), updatedAt: entry.updatedAt?.toISOString() ?? null });
});

router.delete("/bot-context/:id", requireOwner, async (req, res): Promise<void> => {
  const id = parseInt(Array.isArray(req.params.id) ? req.params.id[0] : req.params.id, 10);
  await db.delete(botContextTable).where(eq(botContextTable.id, id));
  res.status(204).send();
});

export default router;
