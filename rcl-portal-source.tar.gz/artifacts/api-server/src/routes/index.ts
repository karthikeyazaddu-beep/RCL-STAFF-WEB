import { Router, type IRouter } from "express";
import healthRouter from "./health";
import authRouter from "./auth";
import applicationsRouter from "./applications";
import staffRouter from "./staff";
import filesRouter from "./files";
import chatRouter from "./chat";
import botContextRouter from "./bot-context";

const router: IRouter = Router();

router.use(healthRouter);
router.use(authRouter);
router.use(applicationsRouter);
router.use(staffRouter);
router.use(filesRouter);
router.use(chatRouter);
router.use(botContextRouter);

export default router;
